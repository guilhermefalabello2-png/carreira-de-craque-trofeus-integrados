# v2.1.9 — Ícones de mando e cores dos resultados

- Corrigido bug na alternância de mando: a lógica anterior calculava casa/fora, mas sempre gravava o clube do jogador como visitante.
- Agora a atribuição de mandante/visitante respeita a alternância calculada para cada rodada.
- Ícone de casa desenhado em SVG minimalista, com traço compatível com o ícone de avião já usado para jogos fora.
- Resultados de liga e Copa do Brasil: vitória do clube do jogador em verde, empate em amarelo e derrota em vermelho.
