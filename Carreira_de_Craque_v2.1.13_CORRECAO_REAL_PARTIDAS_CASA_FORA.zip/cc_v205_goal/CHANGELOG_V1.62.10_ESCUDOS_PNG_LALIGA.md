# v1.62.10 — Correção dos escudos PNG da LaLiga

- Substituídos os endereços dos escudos de Málaga, Racing Santander, Deportivo La Coruña, Valencia e Villarreal por URLs diretas `.png` da coleção FootyLogos.
- Atualizado o cache do Service Worker para forçar a instalação da versão corrigida e guardar os novos endereços no cache de escudos.
- Mantidos os demais 15 clubes, a seleção da Espanha, o calendário e as demais ligas.
- Adicionado teste de regressão que valida os cinco endereços PNG.
