# Relatório técnico — Carreira de Craque v2.1.6

## Base analisada

Projeto extraído do arquivo `Carreira_de_Craque_v2.1.5_MOTOR_PARTIDAS.zip`, que por sua vez veio da base v2.1.4 fornecida na conversa. A aplicação é um jogo web de página única, com JavaScript no `index.html`, armazenamento de carreira no `localStorage`, service worker e configuração Capacitor.

Estruturas reais localizadas:
- `matchRosterProfile` — composição e avaliação setorial do elenco.
- `simulateMatchEngine` — simulação central usada por partidas automáticas e resultados de competições.
- `matchGoalRates` / `simulateScore` — fallback de simulação quando o modo realismo está desligado.
- `resolvePenaltyKick`, `penaltyKickProfile`, `officialShootoutCheck`, `officialShootoutNext`, `officialShootoutRecord` — pênaltis, painel e encerramento matemático.
- `simulateLiveSegment`, `startInteractiveClock`, `resolveInteractiveChoice`, `finishInteractiveMatch` — fluxo de partida com participação do jogador.
- `addLiveEvent`, `showMatchReport`, `cupStoreUserLeg`, `cupPlayLeg` — eventos e armazenamento de partidas.
- `advanceOneDay` — avanço de calendário e recuperação de lesão do jogador da carreira.
- `derbyName` — identificação de confrontos rivais existente no projeto.

## Implementado nesta atualização

A versão 2.1.6 acrescenta uma camada de integração em torno do motor existente. Os pesos setoriais do motor automático foram alinhados com os utilizados no fluxo interativo. A avaliação considera ataque, meio, defesa, goleiro, overall, estrelas, fadiga, tática, expulsões, rivalidade e mando.

A tabela do overall está aplicada no cálculo real:
- Até 59: +0 p.p.
- 60–69: +2 p.p.
- 70–79: +4 p.p.
- 80–89: +6 p.p.
- 90–94: +8 p.p.
- 95–99: +10 p.p.

A simulação automática agora pode registrar revisão de gol por possível impedimento, revisão de falta na área e revisão de expulsão. A decisão afeta placar e estatísticas no mesmo registro de partida. A linha do tempo automática preserva os eventos não-gol e o relatório apresenta eventos com contexto.

As lesões de jogadores de clubes são registradas em `state.clubInjuries`, por ID do atleta, com clube, tipo, gravidade, temporada/dia de início, duração e dias restantes. A recuperação é processada pelo avanço de calendário. Perfis usados na simulação removem atletas indisponíveis e tentam preencher vagas com reservas. Lesões do jogador controlado também recebem gravidade e prazo e são recuperadas pelo relógio da carreira existente.

Os acréscimos são calculados a partir de durações de eventos (cartões, faltas, VAR, lesão, substituição, gol e outros). A contagem do primeiro e segundo tempo é separada. O relógio interativo consulta as interrupções já registradas e atualiza o limite do período.

Pênaltis interativos usam cinco direções e a direção selecionada agora é passada ao resolvedor. O goleiro adversário participa do cálculo por seu perfil de overall/setor. A disputa oficial conserva a checagem matemática existente, com morte súbita sem limite artificial.

O relatório de partida exibe posse, finalizações, finalizações no gol, escanteios, faltas, cartões, defesas e impedimentos, desde que a simulação forneça a métrica correspondente.

## Testes executados

Teste automatizado `tests/match-engine-regression.js`:
- 350 partidas simuladas.
- Placar igual à soma de gols confirmados.
- Gols não excedem finalizações no alvo.
- Finalizações = no alvo + para fora.
- Posse total = 100%.
- IDs de eventos sem duplicação.
- Evento de intervalo, acréscimos e fim de jogo presentes.
- Tabela de seis faixas do overall.
- Cinco direções de pênalti e propagação de direção.
- Eliminação matemática antes do fim das cobranças e alternadas.
- Registro, indisponibilidade e recuperação de lesões.
- Campo neutro sem mando e reconhecimento de rivalidade.

Resultado mais recente: PASS — 350 partidas, 1.250 gols, 8.133 finalizações, 118 revisões de VAR e 2 lesões de clubes geradas na última amostra; favoritos venceram 309 vezes, houve 30 empates e 11 resultados de zebra. Posse/placar/estatísticas/eventos coerentes; cinco direções; regras matemáticas, limiares de overall, campo neutro, rivalidade e recuperação aprovados. Os totais variam entre execuções porque a simulação é probabilística.nalizações, 127 revisões de VAR e 7 lesões de clubes geradas na amostra; favoritos venceram 320 vezes, houve 18 empates e 12 resultados de zebra. Posse/placar/estatísticas/eventos coerentes; cinco direções; regras matemáticas, limiares de overall, campo neutro, rivalidade e recuperação aprovados. Os totais variam entre execuções porque a simulação é probabilística.nalizações; posse/placar/estatísticas/eventos coerentes; 5 direções; regras matemáticas e recuperação aprovadas. Os totais variam entre execuções porque a simulação é probabilística.

Verificação de sintaxe:
- `node --check` do script principal: aprovado.
- `node --check` do service worker: aprovado.

## Limitações ainda abertas

A especificação original solicitava um único motor de ponta a ponta. Nesta entrega, os caminhos automático e interativo ainda têm controladores separados; compartilham a mesma avaliação setorial e tabela de overall, mas não uma única fila de execução. Também não foram concluídos todos os casos de revisão de pênalti/cartão no jogo interativo, nem a aplicação visual de lesões em cada tela de escalação.

A base não possui dados estruturados de público e capacidade dos estádios; não foram criados números fictícios. O pacote original não possui diretório `android/`, então não é possível declarar APK nem projeto Android pronto. A versão entregue é web estática para publicação no Netlify.

O pacote original referencia no service worker vários arquivos de escudos, manifesto, dados e ícones que não estão presentes nele. O service worker foi corrigido para não falhar no pré-cache por arquivos ausentes. Foram criados manifesto e ícones genéricos. Escudos que não estavam na origem continuam ausentes.

## Aviso da limpeza de carreira

Conforme a regra definida para builds de teste, a primeira abertura desta v2.1.6 apaga automaticamente os dados salvos da carreira uma única vez. Os recursos permanentes do jogo não são apagados.
