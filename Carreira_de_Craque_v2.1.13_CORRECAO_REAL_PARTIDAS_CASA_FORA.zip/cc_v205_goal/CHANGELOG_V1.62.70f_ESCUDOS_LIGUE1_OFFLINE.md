# Carreira de Craque v1.62.70f — Escudos da Ligue 1 offline

- Integrados os 18 arquivos de escudos enviados pelo usuário, padronizados em PNG transparente de até 256×256.
- Mantido o mapeamento dos 18 clubes da Ligue 1 para seus respectivos arquivos locais.
- Incluídos os 18 PNGs franceses no pré-cache do Service Worker (APP_SHELL), para que sejam baixados na instalação/atualização e continuem disponíveis sem internet.
- Atualizada a versão do cache PWA para forçar a instalação do novo pacote e a limpeza do cache antigo.
- Mantidos calendário, elencos, tabelas, demais ligas, saves e o painel visual de pênaltis aprovado na base v1.62.70.
