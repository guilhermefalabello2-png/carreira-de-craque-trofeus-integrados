# Carreira de Craque v2.1.6 — Motor de partidas

## Alterações desta versão

- Preservado o motor de partidas existente como implementação-base; a nova camada amplia os mesmos dados de placar, estatísticas e eventos.
- Avaliação de equipe por ataque, defesa, meio-campo e goleiro; utiliza overall, estrelas, condição física, reservas, tática, mando e expulsões.
- Bônus de overall de +0, +2, +4, +6, +8 ou +10 pontos percentuais, conforme a faixa definida no projeto.
- Rivalidade existente participa discretamente do contexto e da intensidade da partida.
- Campo neutro desativa a vantagem de mando.
- VAR acrescentado à simulação automática para gols com possível impedimento, faltas na área e expulsões diretas. No fluxo interativo, gols podem ser revisados e há revisão de expulsão do adversário.
- Lesões leves, moderadas e graves guardadas por ID, com data de início, duração e recuperação pela data da carreira. O perfil de elenco simulado exclui jogadores indisponíveis e tenta usar reservas.
- Acréscimos calculados com base nas durações registradas para interrupções, separados por tempo.
- Eventos estruturados com IDs exclusivos, minuto, equipe, jogador, descrição, duração e estado.
- Estatísticas por equipe ampliadas; correções de placar, finalizações, gols, defesas, cartões e posse.
- Cinco direções de cobrança em pênaltis interativos e alternados; a direção chega ao cálculo e a qualidade do goleiro adversário afeta o resultado.
- Atualização de cache PWA e adição de manifesto/ícones, pois esses arquivos estavam ausentes do ZIP de origem.
- Migração compacta de dados e limpeza única dos saves de teste na primeira abertura, preservando recursos e arquivos permanentes.

## Verificações executadas

- `node --check` do script principal: aprovado.
- `node --check` do service worker: aprovado.
- Teste de regressão de 350 simulações: aprovado.
- Consistência de placar, gols, finalizações, posse e IDs: aprovada.
- Seis faixas de bônus de overall: aprovadas.
- Cinco direções de pênalti e propagação da direção até o resolvedor: aprovadas.
- Encerramento matemático das cinco cobranças e alternadas: aprovado.
- Persistência, indisponibilidade e recuperação de lesões: aprovadas em teste automatizado.
- Reconhecimento de rivalidade e campo neutro: aprovados em teste automatizado.
- Cache local do PWA: lista revisada para não tentar pré-cachear caminhos ausentes.

## Limitações conhecidas

- O fluxo interativo em tempo real e a simulação automática ainda têm controladores de tempo separados. Ambos usam a avaliação setorial, bônus de overall e o mesmo formato de eventos, mas não são ainda uma única função de execução de ponta a ponta.
- Nem todos os acontecimentos disciplinares, pênaltis e revisões do VAR do modo interativo estão cobertos por todos os casos da especificação.
- A indisponibilidade por lesão é aplicada ao perfil de elenco usado na simulação; a montagem de escalação exibida em todas as telas do elenco ainda não foi integrada por completo à lista de lesionados de clubes.
- Público, capacidade e intensidade de torcida por estádio não existem em uma base estruturada no ZIP de origem; foi mantido apenas um fator de mando moderado, sem inventar público/capacidade.
- Não foi possível fazer teste visual dentro de um navegador Android real nesta execução.
- O ZIP de origem não contém a pasta `android/`; portanto esta entrega não inclui projeto Android nativo compilável nem APK. A estrutura web estática pode ser publicada no Netlify.
- O ZIP de origem também não continha o manifesto PWA, ícones de aplicativo nem várias imagens referenciadas pelo service worker. Foram criados manifesto e ícones genéricos e ajustada a lista de pré-cache aos arquivos locais realmente disponíveis; escudos ausentes do pacote de origem não foram inventados.
