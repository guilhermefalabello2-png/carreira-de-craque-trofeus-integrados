# Carreira de Craque v1.59.5 — Copa do Brasil jogável e automática

## Formato e chaveamento
- Mantidos exatamente 56 participantes, sem reinserir os quatro clubes excluídos.
- 1ª fase: 56 clubes em 28 jogos.
- 2ª fase: 24 clubes em 12 jogos e quatro BYEs para os quatro maiores índices de força entre os vencedores da 1ª fase; critério registrado no save e exibido no chaveamento.
- Oitavas (8 confrontos), quartas (4) e semifinal (2) em ida e volta; final em jogo único.
- Removida a repescagem incorreta da versão anterior.
- Empates em jogo único e no agregado vão a pênaltis; sem gol fora.

## Partidas e calendário
- O jogo do clube controlado pelo usuário fica pendente para ser disputado no fluxo interativo normal.
- Os demais confrontos são simulados automaticamente pelo motor de partidas quando a data chega.
- Ao avançar dias, a carreira respeita a próxima data da Copa antes de saltar para a rodada seguinte do Brasileirão.
- Ida e volta do clube do usuário são tratadas separadamente e persistidas.
- O destaque azul e o calendário unificado em Partidas foram preservados; a tela da Copa em Ligas continua exibindo fases, BYEs, placares e classificados.
- Resultados automáticos guardam estatísticas de equipe e eventos essenciais (gols/cartões) para reduzir o consumo de armazenamento.

## Zebras e pênaltis
- A calibração específica da Copa reforça a influência das estrelas e da diferença de qualidade dentro do mesmo motor de eventos, sem alterar o cálculo das outras competições.
- A disputa de pênaltis usa cinco cobranças e morte súbita, com chance de conversão influenciada pela força relativa dos elencos, sem resultado pré-determinado.

## Testes locais executados
- Sintaxe JavaScript verificada em `index.html` e `index_debug.html`.
- Teste estrutural das seis fases: 56 participantes, 28 jogos na 1ª fase, 12 jogos + 4 BYEs na 2ª, depois 8/4/2/1 confrontos.
- Teste de jogo do usuário: confronto permanece pendente enquanto 27 outros jogos são simulados automaticamente.
- Teste de calendário: jogos iniciais fora das datas semanais do Brasileirão e sem dupla marcação do mesmo clube no mesmo dia.
- Teste de progressão do chaveamento até a final e campeão.
- Simulação Monte Carlo de 10.000 partidas por faixa sintética de força; em grande diferença, o azarão venceu aproximadamente 2,1% das partidas incluindo pênaltis; diferença moderada ficou próxima de 10,7%; diferença pequena, 21,6%.
- ZIP será validado por integridade após empacotamento.

## Observações
- A limpeza automática dos saves ocorre uma única vez nesta versão, por autorização do usuário, preservando arquivos estáticos, clubes, elencos e escudos.
- Os testes são automatizados em ambiente local; ainda é necessário confirmar o fluxo visual e de navegação no Android/Netlify.
