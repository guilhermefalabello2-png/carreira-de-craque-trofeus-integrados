# Carreira de Craque — v1.60.5

- Corrigidos os uniformes de Vitória, Grêmio, Botafogo e Athletico Paranaense conforme as referências enviadas.
- A identificação dos clubes agora reconhece variações de nome usadas nos elencos profissional e Sub-20.
- As alterações são aplicadas no renderizador principal da camisa e na visualização alternativa.
- Uniforme do Santos preservado sem alterações nesta atualização.
- Cache do aplicativo atualizado para carregar os novos uniformes offline.
- Nenhum outro sistema de carreira foi intencionalmente alterado.
