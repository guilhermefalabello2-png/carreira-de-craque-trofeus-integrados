# v1.53.0 — Criação de carreira Sub-20

- Define aparência inicial segura quando o formulário não fornece campos opcionais.
- Se a carreira já foi salva e uma falha ocorrer ao abrir a interface seguinte, recupera a tela inicial em vez de informar falsamente que a carreira não foi criada.
- Mostra o detalhe da exceção no aviso para permitir identificar a causa real caso a criação falhe antes de salvar.
- Atualiza a versão do cache do service worker.

Validação local: sintaxe JavaScript e teste de classificação. O fluxo não foi validado dentro do aplicativo Android.
