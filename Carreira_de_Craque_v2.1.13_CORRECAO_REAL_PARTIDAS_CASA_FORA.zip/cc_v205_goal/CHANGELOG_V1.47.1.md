# v1.47.1 — Série C em Ligas > Brasil avança com a carreira

- Corrigida a causa específica da tabela travada em `Ligas > Brasil > Série C`: `brazilWorldAutoAdvance()` avançava apenas as Séries A e B.
- A rotina agora avança também a Série C, preenchendo os placares da rodada, atualizando `round` e salvando os dados na mesma chave local já usada pela tela.
- Não alteradas as regras, o calendário ou a lógica de classificação das Séries A e B; elas continuam no mesmo fluxo anterior.
- Não reseta o progresso existente. A Série C volta a avançar a partir da próxima rodada simulada.
