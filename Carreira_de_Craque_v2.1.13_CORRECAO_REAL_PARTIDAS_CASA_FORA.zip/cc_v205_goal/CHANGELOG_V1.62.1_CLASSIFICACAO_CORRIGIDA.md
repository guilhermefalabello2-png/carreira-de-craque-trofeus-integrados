# Carreira de Craque v1.62.1 — Classificação corrigida

- Corrigida a leitura dos placares sempre no padrão mandante–visitante.
- A classificação não usa mais o histórico individual do atleta como fonte concorrente para corrigir placares, evitando importar resultados invertidos.
- Todos os resultados de partidas profissionais passam a persistir também `homeGoals` e `awayGoals`, além do placar legado.
- A reconstrução da tabela aplica a regra 3 pontos por vitória, 1 por empate e 0 por derrota para todos os clubes da divisão.
- Teste de regressão cobre vitória, empate e derrota com o clube como mandante e visitante, além dos formatos de placar antigos.
