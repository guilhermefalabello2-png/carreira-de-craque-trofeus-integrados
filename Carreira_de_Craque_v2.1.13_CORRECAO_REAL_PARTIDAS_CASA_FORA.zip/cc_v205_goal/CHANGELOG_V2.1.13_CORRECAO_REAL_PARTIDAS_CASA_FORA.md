# Carreira de Craque v2.1.13 — Correção real de casa/fora na aba Partidas

- Corrigido o arquivo efetivamente carregado pelo aplicativo (`index.html`).
- A função anterior sempre atribuía o clube do jogador ao campo `away` quando precisava ajustar uma rodada; por isso todas as partidas apareciam como fora.
- Agora o clube do jogador é colocado em `home` quando o mando desejado é em casa e em `away` quando o mando desejado é fora.
- O calendário da aba Partidas aplica a correção antes de montar a lista e salva somente quando algum confronto futuro é ajustado.
- Partidas concluídas e partida em andamento não são invertidas. O estádio acompanha o mandante real.
- A leitura do mando usa comparação normalizada do nome do clube.
- O ícone da casa foi preservado e o avião foi redesenhado em SVG de vista superior, branco, com fuselagem, asas e cauda.
- Cache PWA atualizado para disponibilizar o `index.html` novo após a instalação da versão.
