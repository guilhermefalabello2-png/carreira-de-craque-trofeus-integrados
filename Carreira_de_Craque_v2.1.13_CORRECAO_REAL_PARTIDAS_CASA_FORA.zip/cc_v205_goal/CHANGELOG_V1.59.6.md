# Carreira de Craque v1.59.6

- Corrigido o fluxo de navegação da aba LIGAS: ao abrir a aba, ela sempre retorna ao menu principal de competições; seleção Brasil, Copa do Brasil, Sub-20 e ligas internacionais permanece funcional.
- Copa do Brasil refeita para 48 participantes: 20 clubes da Série A, 20 da Série B e os 8 clubes de maior força da Série C.
- Os 32 clubes restantes disputam 16 confrontos na fase preliminar; os 16 clubes de maior força entram na 2ª fase. Isso é entrada por fase, não BYE: nenhum clube é classificado automaticamente dentro de uma fase.
- Chaveamento: fase preliminar (32→16), 2ª fase (32→16), oitavas (16→8), quartas (8→4), semifinal (4→2), final (2→1).
- Fase preliminar e 2ª fase em jogo único; oitavas, quartas e semifinal em ida e volta; final em jogo único. Sem gol fora; pênaltis conforme regra.
- Preservados calendário integrado, partidas do usuário jogáveis, simulação automática dos demais confrontos, motor de partidas e histórico de campeões.
- Atualizado cache do PWA para v1.59.6.
