# Carreira de Craque v1.60.3

- Atlético Mineiro: nome do jogador e número da camisa titular agora aparecem em amarelo, mantendo o uniforme listrado preto e branco.
- Nenhum outro clube ou funcionalidade foi alterado intencionalmente.
