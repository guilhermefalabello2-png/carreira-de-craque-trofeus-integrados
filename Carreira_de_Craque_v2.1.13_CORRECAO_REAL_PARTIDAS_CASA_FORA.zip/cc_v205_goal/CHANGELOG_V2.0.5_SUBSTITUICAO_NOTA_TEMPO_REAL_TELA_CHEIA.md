# Carreira de Craque v2.0.5 — Substituição, nota ao vivo e tela cheia

- Adicionada chance de substituição por baixo rendimento a partir dos 55 minutos, com probabilidade maior conforme a nota cai.
- A nota do jogador passa a aparecer em tempo real na tela PARTIDA EM ANDAMENTO.
- A nota final usa a mesma fórmula da avaliação ao vivo, sem variação aleatória no apito final.
- Removida da interface a exibição dos acréscimos previstos do primeiro e do segundo tempo; o relógio e os acréscimos continuam funcionando.
- A tela PARTIDA EM ANDAMENTO agora ocupa toda a área disponível do celular.
- Preservadas as mecânicas e correções da versão 2.0.4.
