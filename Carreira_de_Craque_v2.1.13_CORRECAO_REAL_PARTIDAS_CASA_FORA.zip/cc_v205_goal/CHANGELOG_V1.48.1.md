# Carreira de Craque v1.48.1 — Faixas do Flamengo corrigidas

- Ajustado o uniforme titular do Flamengo para manter o corpo preto com faixas horizontais vermelhas, seguindo a referência enviada.
- Alterada somente a distribuição das faixas e o vermelho/preto do padrão visual; números, nomes, escudos, gola, mangas e demais elementos permanecem inalterados.
- A correção usa o mesmo catálogo de uniformes compartilhado pelo modo profissional e pelo Sub-20.
