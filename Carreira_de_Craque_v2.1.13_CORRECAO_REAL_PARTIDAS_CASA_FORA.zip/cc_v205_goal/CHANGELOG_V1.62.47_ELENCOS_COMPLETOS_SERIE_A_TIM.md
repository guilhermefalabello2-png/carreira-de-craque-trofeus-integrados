# v1.62.47 — Elencos da Serie A TIM

- Integrados os 20 elencos italianos enviados pelo usuário, com nome, camisa e posição.
- Os elencos passam a alimentar o sistema de escalação e a simulação das partidas via `rosterForClub`.
- Adicionada a visualização de elenco e camisas para a Serie A TIM na tela de Ligas Europeias.
- Números repetidos foram preservados conforme a lista original e destacados na tabela.
- OVRs são estimativas de gameplay derivadas da força do clube e posição, não notas oficiais.
- Não foram alterados os elencos das outras ligas nem o calendário da Serie A TIM.
