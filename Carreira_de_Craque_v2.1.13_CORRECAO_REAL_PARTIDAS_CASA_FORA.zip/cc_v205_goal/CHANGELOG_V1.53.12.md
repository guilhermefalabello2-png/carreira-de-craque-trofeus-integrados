# v1.53.12 — Correção do bloqueio de partidas

- A partida salva só é retomada se corresponder exatamente ao jogo pendente da temporada/rodada atual e tiver estrutura válida de intervalo.
- Uma sessão antiga ou incompleta é liberada sem marcar a partida como disputada, sem alterar placares/histórico e sem apagar a carreira.
- Uma sessão válida de intervalo abre diretamente o vestiário para continuar o segundo tempo.
- Ao carregar a carreira, sessões incompatíveis são descartadas antes de salvar o estado corrigido.
- Cache do PWA atualizado para evitar que o navegador continue usando o JavaScript antigo.

Validação local: sintaxe do script, integridade do ZIP e testes automatizados disponíveis. Não equivale a teste físico no Samsung Galaxy S10.
