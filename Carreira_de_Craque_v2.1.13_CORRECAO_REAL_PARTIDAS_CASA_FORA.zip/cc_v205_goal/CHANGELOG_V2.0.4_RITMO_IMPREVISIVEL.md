# v2.0.4 — Ritmo imprevisível das participações

- Removido o agendamento de decisões por faixas fixas de minutos.
- Oportunidades avaliadas minuto a minuto por probabilidade dinâmica, aumentando gradualmente enquanto não surge uma situação.
- Intervalos de respiro aleatórios após decisões, evitando ciclos repetitivos.
- Ajuste aplicado também após decisões e no início do segundo tempo.

O restante do sistema de partidas foi preservado.
