# Carreira de Craque v2.1.2 — Comemorações e tela cheia

- Corrigida a exibição indevida/aleatória da escolha de comemoração.
- A escolha de comemoração é apresentada imediatamente após um gol confirmado com participação do jogador.
- Adicionadas opções de comemoração com a torcida, abraço aos companheiros, comemoração característica, provocação ao adversário e retorno rápido ao meio-campo.
- Modais e telas de lances passam a ocupar toda a área disponível da tela, com suporte às áreas seguras do dispositivo.
- Preservados os demais recursos e arquivos do projeto.
