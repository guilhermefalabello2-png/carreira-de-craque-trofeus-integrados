# Carreira de Craque v1.63.13 — Tabelas automáticas corrigidas

- Em **Ligas**, Premier League, LaLiga, Serie A Enilive, Ligue 1 e Bundesliga exibem somente a tabela, sem controles de simulação de rodada, seleção de partidas ou reinício.
- As cinco ligas europeias usam a mesma tabela independente e avançam automaticamente quando a rodada da carreira é concluída.
- Quando a carreira do jogador pertence a uma dessas ligas, o placar real da partida do jogador é aplicado à tabela correspondente; os demais jogos da rodada são simulados automaticamente.
- Bundesliga usa sempre a chave interna canônica `bundes`, corrigindo o acesso à tabela para qualquer carreira.
- Pontuação uniforme em todas as tabelas: vitória = 3 pontos, empate = 1 ponto e derrota = 0 ponto.
- Em Ligas > Brasil, permanecem as tabelas das Séries A, B e C e o acesso à Copa do Brasil; a Copa mantém seu formato próprio.
- Nenhuma alteração nos menus de Partidas, calendário ou fluxo de simulação do atleta.
