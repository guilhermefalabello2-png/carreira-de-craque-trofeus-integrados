# Patch de logos das competições

O instalador de patches do Carreira de Craque v1.63.11 aceita logos de competições no campo `competitionLogos` do `patch.json`.

IDs aceitos:
- `COMP-BRA-SERIE-A`
- `COMP-BRA-SERIE-B`
- `COMP-BRA-SERIE-C`
- `COMP-BRA-COPA-DO-BRASIL`
- `COMP-ENG-PREMIER-LEAGUE`
- `COMP-ESP-LALIGA`
- `COMP-ITA-SERIE-A-ENILIVE`
- `COMP-GER-BUNDESLIGA`

O ZIP do patch deve conter `patch.json` na raiz e os arquivos de imagem nos caminhos informados no manifesto. Formatos aceitos: PNG, JPG, JPEG, WebP e SVG. Limite de 2 MB por imagem.

O campo `crests` continua aceito para escudos de clubes. É possível enviar `crests` e `competitionLogos` juntos no mesmo patch.

Use `patch-competicoes-template.json` como modelo e ajuste os caminhos conforme os nomes reais dos arquivos do seu patch.
