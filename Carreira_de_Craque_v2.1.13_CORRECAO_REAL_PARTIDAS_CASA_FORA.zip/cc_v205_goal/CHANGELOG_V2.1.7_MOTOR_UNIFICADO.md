# Carreira de Craque 2.1.7 — Modelo compartilhado

## Atualizações
- Acréscimos calculados por interrupções distintas, sem somar várias mensagens do mesmo minuto como se fossem paralisações separadas.
- Acréscimos do modo interativo são travados quando o tempo regulamentar termina, evitando extensão recursiva durante os próprios acréscimos.
- Faltas na área podem gerar revisão do VAR e pênalti confirmado ou cancelado; quando o jogador está apto, ele pode assumir a cobrança.
- Cobranças de pênalti são registradas como penalidade e não passam indevidamente por revisão de impedimento.
- Elegibilidade para bater pênalti deixa de exigir 100 de confiança do treinador.
- Ajustes de disciplina/VAR no jogo ao vivo, fadiga do adversário e estatísticas de passes.
- Jogadores lesionados aparecem identificados no elenco e são excluídos da montagem de escalações.
- Corrigida contagem duplicada de lesões do jogador da carreira.
- Removida a limpeza automática específica da versão de teste 2.1.6; esta atualização preserva os saves existentes.
- Cache PWA atualizado para a versão 2.1.7.

## Validação
- `node --check` do JavaScript principal e do service worker.
- Testes de regressão do motor automático (350 partidas), estatísticas, overall, campo neutro, rivalidade, lesões, recuperação e pênaltis.
- Não é um teste visual em aparelho Android; o projeto permanece em formato web/PWA.
