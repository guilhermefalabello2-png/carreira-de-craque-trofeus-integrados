PASTA DE TROFÉUS — CARREIRA DE CRAQUE

Esta pasta contém o registro de destino das nove imagens oficiais de troféus.
Nenhuma imagem foi criada ou incluída nesta atualização.

Adicionar futuramente os arquivos PNG com estes nomes exatos:
- TROPHY-BRA-SERIE-A.png
- TROPHY-BRA-SERIE-B.png
- TROPHY-BRA-SERIE-C.png
- TROPHY-BRA-SUB20.png
- TROPHY-BRA-COPA-DO-BRASIL.png
- TROPHY-ENG-PREMIER-LEAGUE.png
- TROPHY-ESP-LALIGA.png
- TROPHY-FRA-LIGUE-1.png
- TROPHY-GER-BUNDESLIGA.png

Os nomes dos arquivos correspondem aos IDs permanentes do TROPHY_REGISTRY.
Usar PNG com transparência quando disponível. A interface renderiza as imagens
centralizadas com object-fit: contain, preservando a proporção e sem cortes.
Enquanto o arquivo não existir, a sala de troféus mostra um espaço reservado.
