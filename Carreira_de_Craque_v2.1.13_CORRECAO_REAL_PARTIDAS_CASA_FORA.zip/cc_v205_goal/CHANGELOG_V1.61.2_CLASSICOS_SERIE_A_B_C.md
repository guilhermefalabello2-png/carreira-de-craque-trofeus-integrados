# v1.61.2 — Clássicos das Séries A, B e C

- Ampliado o cadastro de clássicos brasileiros usando exclusivamente clubes existentes nas listas BR_A, BR_B e BR_C.
- Incluídos Majestoso (Corinthians x São Paulo), Clássico da Saudade (Palmeiras x Santos) e Clássico da Amizade (Vasco x Botafogo), entre outros confrontos tradicionais ausentes.
- Incluídos clássicos relevantes entre clubes das três divisões, como Re-Pa, Ca-Ju, Dérbi Campineiro e Clássico Sergipano.
- Corrigido o nome cadastrado de Sport para Sport Recife para coincidir com o cadastro oficial do jogo.
- Mantidos os clássicos da Premier League já existentes.
- O reconhecimento continua bidirecional e só ativa quando ambos os clubes existem no cadastro de suas ligas.
