# Relatório técnico — Legado profissional (v1.53.5)

## Comparação real dos fluxos

- **Sub-20:** `sub20Load()` recupera uma liga separada por carreira/temporada do `localStorage`; `sub20Table()` calcula a classificação a partir dos jogos salvos; `finishBaseSeason()` grava essa tabela final no histórico. A base usa `state.baseMode` e a fonte `cc_sub20_league_career_<careerId>`.
- **Profissional:** `finishSeason()` usa `state.fixtures`, exige 38 rodadas completas/380 partidas, reconstrói `finalRows`, e grava `finalTable`, `finalFixtures`, `position`, `champion`, `competitionId`, `careerId` e `finalized` em `seasonHistory`. O Legado visual é compartilhado, mas os fluxos de encerramento e as fontes não são.
- **Histórico/contagem:** `historyView()` decide o troféu via `legacyVerifiedChampion()`. `careerStats.titles` era um contador salvo separado; um valor antigo não era prova da validade do registro que a tela exibia.

## Causa raiz do caminho de falso positivo

A validação anterior tinha duas permissões inseguras: aceitava um registro sem `finalized: true` e aceitava fixtures profissionais sem `season`/`competitionId`, desde que os campos de posição/campeão e o snapshot antigo fossem coerentes entre si. Isso permite que um snapshot antigo seja aceito como prova definitiva de outra temporada. O defeito foi reproduzido em regressão com fixtures completos sem os carimbos de identidade.

O save local do usuário não está disponível para inspeção direta nesta execução; portanto, não é possível afirmar qual registro específico do aparelho contém esses dados. A correção torna esse caminho impossível: registros antigos sem prova completa continuam armazenados, mas ficam sem posição/título profissional confirmado até que haja evidência suficiente.

## Correção

- `legacyResolveSeasonOutcome()` exige `finalized === true`.
- Para ligas profissionais, cada fixture deve carregar `season` e `competitionId` exatos do registro, além de passar pela validação de 380 jogos, 20 clubes, 38 aparições por clube e dois confrontos por par.
- `legacySeasonPosition()` não apresenta posição profissional a partir de snapshot antigo/incompleto.
- `historyView()` só exibe troféu após validação integral.
- O contador visual passa a exibir títulos profissionais comprovados. Valores antigos não verificáveis permanecem salvos e são identificados como pendentes, em vez de serem apagados ou declarados verdadeiros.
- O registro do título no encerramento profissional é acionado uma única vez.
- A chave de cache do service worker foi atualizada para v1.53.5.

## Testes executados

- `tests/legacy-regression.js`: PASS — 1º, 2º e 5º lugares; temporada incompleta; snapshot sem carimbos; temporada errada; não duplicação; contador; interface; salvar/recarregar; Sub-20 isolado e persistência.
- `tests/standings-regression.js`: PASS.
- `tests/promotion-relegation-ligas.js`: PASS.
- `node --check` do JavaScript extraído de `index.html`: PASS.
- Comparação textual: `sub20Teams()`, `sub20Load()`, `sub20Table()` e `finishBaseSeason()` permaneceram idênticas à v1.53.4.
- `tests/smoke-test.js`: continua falhando no teste preexistente “career systems initialized with identified real roster records”. Essa mesma falha ocorre na base v1.53.1 e na v1.53.3; não é apresentada como resolvida por esta mudança.
- Não foi realizado teste visual em navegador/dispositivo nesta execução.
