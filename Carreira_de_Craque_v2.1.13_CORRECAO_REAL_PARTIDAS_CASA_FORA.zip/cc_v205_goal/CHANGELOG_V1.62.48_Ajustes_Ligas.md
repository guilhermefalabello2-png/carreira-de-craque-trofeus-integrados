# Carreira de Craque v1.62.48 — Ajustes na tela de Ligas

- Renomeada a competição italiana de **Serie A TIM** para **Serie A Enilive** nos textos exibidos pelo jogo. As chaves internas e os dados dos clubes foram preservados.
- Na tela da **Premier League**, removido o bloco redundante **Escolher competição**. O cabeçalho, a classificação e os demais dados da liga continuam visíveis.
- Nas telas independentes do **Brasileirão Série A, B e C**, removidos os botões duplicados de navegação entre divisões e o painel verde de andamento da temporada, conforme solicitado.
- Mantidos os botões de seleção A/B/C e Copa do Brasil na tela anterior de Brasil, assim como as tabelas, calendários, resultados, classificação e regras de acesso/rebaixamento.
- Nenhuma limpeza adicional de saves foi adicionada nesta versão.

## Verificações
- Sintaxe JavaScript validada com `node --check`.
- Confirmada a remoção dos controles duplicados da tela de divisão brasileira.
- Confirmada a condição que oculta o seletor de competição somente na Premier League.
- Confirmada a substituição dos rótulos antigos da Serie A TIM.
