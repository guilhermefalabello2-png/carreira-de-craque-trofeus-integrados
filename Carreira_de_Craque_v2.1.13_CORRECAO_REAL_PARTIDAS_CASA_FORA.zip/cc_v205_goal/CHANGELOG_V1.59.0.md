# v1.59.0 — Copa do Brasil e seleção profissional brasileira

- Adicionada Copa do Brasil no menu Competições, com 60 clubes das Séries A, B e C, BYEs definidos pelo critério transparente de força cadastrada, seis fases, ida e volta nas oitavas/quartas/semifinais, final em jogo único, pênaltis e histórico de campeão.
- As partidas usam `simulateMatchEngine`, o motor de partidas compartilhado pelo jogo.
- Sorteio, participantes, calendário, placares, classificados e campeão ficam salvos dentro do save da carreira.
- A agenda da Copa registra datas e procura evitar colisões com as datas estimadas do calendário das ligas e manter intervalo de segurança entre jogos da própria Copa.
- A tela Escolher País e Clube agora permite iniciar carreira profissional com clubes da Série A, B ou C, além da opção Sub-20 já existente.
- Nenhuma carreira salva é apagada nesta versão.

## Limitações conhecidas
- O calendário ainda não substitui o agendamento legado das rodadas de liga por um serviço central único; a Copa usa uma agenda persistente com verificação contra datas estimadas das ligas.
- A Copa é simulada por fase no painel da competição; a partida do atleta ainda não é encaminhada ao fluxo interativo de pré-jogo/partida/relatório.
- A premiação financeira é creditada quando a fase é concluída e a carreira do usuário tem participação no torneio; requer validação em jogo real.
