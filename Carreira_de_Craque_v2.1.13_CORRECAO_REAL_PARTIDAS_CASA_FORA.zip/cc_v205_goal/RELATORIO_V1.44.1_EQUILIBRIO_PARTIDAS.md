# Carreira de Craque v1.44.1 — relatório de correção

## Causa identificada
Na função `simulateScore`, o cálculo anterior comparava o ataque mandante com a própria defesa (`hAttack - hDef`), em vez da defesa visitante. No cálculo dos gols visitantes, o ataque visitante também era somado em dois ajustes (`aAttack - hDef` e `aAttack - aDef`). Isso aplicava o ataque de forma duplicada e não modelava corretamente o confronto ataque x defesa.

## Alterações
- Corrigida a relação entre ataque de cada time e defesa adversária.
- Ajustes graduais de força geral, qualidade ofensiva e defesa aplicados uma única vez.
- Mantida a distribuição de Poisson para gerar os gols, sem teto artificial de placar.
- O placar sorteado continua sendo a única fonte de verdade: os registros de gols são criados para corresponder à quantidade final.
- `simulateLeagueGame` continua recusando partidas com `played === true`, evitando processar novamente a mesma partida.
- Preservados estrelas, elencos, atributos e dados salvos.

## Teste estatístico
Foi executado um teste de 10.000 partidas para cada um de dois perfis, antes e depois, com parâmetros representativos. Resultados de amostra (podem variar ligeiramente entre execuções por aleatoriedade):

| Perfil | Motor | Gols/partida | Empates | Diferença ≥3 gols | Alguma equipe com 6+ gols |
|---|---|---:|---:|---:|---:|
| Equipes equilibradas | Antes | 2,642 | 25,20% | 12,64% | 0,61% |
| Equipes equilibradas | Depois | 2,594 | 25,31% | 12,16% | 0,55% |
| Favorito forte em casa | Antes | 2,596 | 23,28% | 16,62% | 0,91% |
| Favorito forte em casa | Depois | 2,555 | 23,51% | 15,78% | 0,93% |

Vitórias por exatamente um gol: equilibrados 40,55% antes / 40,53% depois; favorito forte em casa 38,00% antes / 38,17% depois.

## Interpretação e limitações
A média do perfil equilibrado ficou dentro da faixa inicial solicitada (2,4–3,0 gols). A frequência de diferenças de três ou mais gols diminuiu modestamente nos dois perfis. Resultados de seis ou mais gols por uma equipe permanecem raros, mas possíveis. O teste estatístico valida o comportamento da fórmula isolada com parâmetros representativos; não equivale a 10.000 jogos executados na interface nem comprova, sozinho, persistência após recarga ou todas as regras de cada competição.

## Verificações técnicas
- `node --check` executado sobre o JavaScript inline: aprovado.
- ZIP validado com `unzip -t`: será verificado no pacote final.
