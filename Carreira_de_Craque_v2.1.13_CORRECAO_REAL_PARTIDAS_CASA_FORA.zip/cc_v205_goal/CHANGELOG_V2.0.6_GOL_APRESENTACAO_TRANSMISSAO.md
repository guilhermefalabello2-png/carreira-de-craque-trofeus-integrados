# Carreira de Craque v2.0.6 — Gol com apresentação de transmissão

- Aviso especial de gol para os dois clubes durante a partida interativa.
- Escudo do clube, chamada GOL DO [CLUBE]!, autor, minuto e descrição curta do lance.
- Assistências e cobranças de pênalti mantêm o autor correto.
- Gols simultâneos são apresentados em sequência; o relógio só retoma após CONTINUAR PARTIDA.
- Cache do service worker atualizado para carregar a nova versão.
