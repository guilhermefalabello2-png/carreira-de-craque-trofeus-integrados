# Relatório técnico — v2.1.7

Base: Carreira_de_Craque_v2.1.6_MOTOR_PARTIDAS_REALISTA.zip.

A atualização completa partes que estavam incompletas na integração de partidas: VAR e pênaltis em partidas interativas, acréscimos com bloqueio no momento correto, dados de passes ao vivo, disponibilidade visual de atletas lesionados e preservação dos saves.

A simulação automática já possuía motor por eventos, força por setores, mando, rivalidade, VAR, lesões persistentes e estatísticas conciliadas; essas rotinas foram mantidas. O motor automático e o modo interativo compartilham agora a mesma avaliação-base por minuto (setores, estrelas, mando, rivalidade, fadiga, tática e expulsões), mantendo ritmos próprios para simulação completa e relógio ao vivo. O modo interativo mantém decisões do jogador e passa a ligar faltas na área, revisão e cobrança de pênalti.

Limitação: não foi executado teste visual em navegador real nem compilação Android/APK. Foram executados testes automatizados de lógica e verificação sintática.
