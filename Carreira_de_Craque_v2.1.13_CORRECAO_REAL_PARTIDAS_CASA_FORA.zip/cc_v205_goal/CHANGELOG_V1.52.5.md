# v1.52.5 — Legado: campeão verificado

- A tela Legado não exibe mais troféu/título apenas porque a posição salva é 1º.
- O campeão é validado contra a tabela final da competição e, nas ligas brasileiras, contra o histórico de campeões e a tabela da divisão correta.
- O Sub-20 passa a guardar uma cópia da classificação final para verificar a posição e o título em temporadas futuras.
- Temporadas antigas sem evidência suficiente deixam de receber automaticamente o rótulo de campeão; a posição registrada continua visível.
