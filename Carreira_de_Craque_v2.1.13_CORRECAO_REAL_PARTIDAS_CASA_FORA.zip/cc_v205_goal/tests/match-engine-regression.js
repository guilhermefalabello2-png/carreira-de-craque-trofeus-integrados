const fs=require('fs');
const vm=require('vm');
const path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const scripts=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/gi)].map(x=>x[1]).filter(Boolean);
if(!scripts.length)throw new Error('Script principal não encontrado');
const source=scripts[scripts.length-1];
function section(startText,endText){
  const start=source.indexOf(startText);
  if(start<0)throw new Error('Trecho ausente: '+startText);
  const end=endText?source.indexOf(endText,start+startText.length):-1;
  if(endText&&end<0)throw new Error('Fim de trecho ausente: '+endText);
  return source.slice(start,end<0?source.length:end);
}
const baseEngine=section('function simulateMatchEngineBase(','\nfunction renderTabs');
const integration=section('const CC_MATCH_ENGINE_VERSION', '\nfunction advanceOneDay(){');
const profile=(club)=>({
  atk:club==='Fortíssimo'?94:club==='Defesa Forte'?76:61,
  def:club==='Defesa Forte'?92:club==='Fortíssimo'?73:59,
  mid:club==='Fortíssimo'?90:club==='Defesa Forte'?68:61,
  gk:club==='Fortíssimo'?92:club==='Defesa Forte'?83:58,
  shooting:club==='Fortíssimo'?93:68,
  passing:club==='Fortíssimo'?89:67,
  pace:club==='Fortíssimo'?87:66,
  defending:club==='Defesa Forte'?90:63,
  stamina:club==='Cansado'?48:75,
  overall:club==='Fortíssimo'?92:club==='Defesa Forte'?78:62,
  stars:club==='Fortíssimo'?5:club==='Defesa Forte'?3.5:2,
  xi:Array.from({length:11},(_,i)=>({
    id:club.replace(/\W/g,'')+'-'+i,name:`Jogador ${i+1} ${club}`,
    pos:i===0?'Goleiro':i<5?'Zagueiro':i<8?'Meia':'Atacante',
    ovr:club==='Fortíssimo'?92:club==='Defesa Forte'?78:62
  })),
  bench:Array.from({length:7},(_,i)=>({
    id:club.replace(/\W/g,'')+'-b'+i,name:`Reserva ${i+1} ${club}`,pos:i===0?'Goleiro':'Atacante',
    ovr:club==='Fortíssimo'?88:club==='Defesa Forte'?73:60
  }))
});
const context={
  Math,console,
  clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),
  rand:(a,b)=>Math.floor(Math.random()*(b-a+1))+a,
  chance:p=>Math.random()<p,
  weightedPick:arr=>{const total=arr.reduce((s,x)=>s+x.w,0);let r=Math.random()*total;for(const x of arr){r-=x.w;if(r<=0)return x.v;}return arr[arr.length-1].v;},
  derbyName:(a,b)=>((a==='Clube A'&&b==='Clube B')||(a==='Clube B'&&b==='Clube A'))?'Clássico de teste':null,
  matchRosterProfileBase:profile,
  state:{id:'regression',season:2026,day:10,p:{energy:75,fitness:75,ovr:74,penaltySkills:{left:60,right:60,center:60}},clubInjuries:{},matchEventSequence:0,careerStats:{injuries:0},news:[]},
  news:(text,icon)=>context.state.news.push({text,icon}),
  interactiveIsOnPitch:()=>true
};
vm.createContext(context);
vm.runInContext(baseEngine,context);
vm.runInContext(integration,context);
let sumGoals=0,sumShots=0,injuries=0,varReviews=0,addedTimeMatches=0,favoriteWins=0,draws=0,upsets=0;
for(const [ovr,bonus] of [[55,0],[65,2],[75,4],[85,6],[92,8],[97,10]])if(context.ccOverallBonus(ovr)!==bonus)throw new Error('Bônus de overall incorreto para '+ovr);
for(let i=0;i<350;i++){
  context.state={id:'regression-'+i,season:2026,day:10,clubInjuries:{},matchEventSequence:0,p:{energy:75,fitness:75,ovr:74,penaltySkills:{left:60,right:60,center:60}},careerStats:{injuries:0},news:[]};
  const r=context.simulateMatchEngine('Fortíssimo','Inferior',{});
  if(r.stats.home.possession+r.stats.away.possession!==100)throw new Error('Posse não soma 100%');
  for(const side of ['home','away']){
    const s=r.stats[side];
    if(s.goals>s.onTarget||s.onTarget>s.shots)throw new Error('Estatística de finalização inconsistente');
    if(s.shots!==s.onTarget+s.shotsOff)throw new Error('Finalizações não fecham em no alvo + fora');
    if(s.goals!==r.score[side==='home'?0:1])throw new Error('Gols divergem do placar');
  }
  const goals=r.events.filter(e=>e.type==='goal').length;
  if(goals!==r.score[0]+r.score[1])throw new Error('Placar diverge da linha de eventos');
  const ids=r.events.map(e=>e.id);
  if(new Set(ids).size!==ids.length)throw new Error('IDs duplicados');
  if(!r.addedTime||r.addedTime.firstHalf<1||r.addedTime.secondHalf<1)throw new Error('Acréscimos não calculados');
  if(!r.events.some(e=>e.type==='half')||!r.events.some(e=>e.type==='final'))throw new Error('Eventos de intervalo/fim ausentes');
  sumGoals+=goals;sumShots+=r.stats.home.shots+r.stats.away.shots;if(r.score[0]>r.score[1])favoriteWins++;else if(r.score[0]===r.score[1])draws++;else upsets++;
  injuries+=r.events.filter(e=>e.type==='injury').length;
  varReviews+=r.events.filter(e=>e.type==='var_review').length;
  addedTimeMatches++;
}
const expected=[0,2,4,6,8,10];
// v2.1.7: interrupções simultâneas não podem inflar os acréscimos.
const groupedAdded=context.ccAddedMinutes([
  {minute:42,half:'1T',type:'var_review',durationSeconds:55},
  {minute:42,half:'1T',type:'var_decision',durationSeconds:5},
  {minute:42,half:'1T',type:'foul',durationSeconds:14}
],1);
if(groupedAdded!==1)throw new Error('Interrupções simultâneas foram contadas mais de uma vez');
const injuryAdded=context.ccAddedMinutes([{minute:40,half:'1T',type:'injury',durationSeconds:95}],1);
if(injuryAdded!==2)throw new Error('Lesão não foi considerada no cálculo de acréscimos');
const firstHalf={phase:'interactive',currentMinute:45,events:[{minute:40,half:'1T',type:'injury',durationSeconds:95}]};
const lockedLimit=context.interactiveHalfLimit(firstHalf);
firstHalf.events.push({minute:46,half:'1T',type:'var_review',durationSeconds:55});firstHalf.currentMinute=47;
if(context.interactiveHalfLimit(firstHalf)!==lockedLimit)throw new Error('Acréscimos do primeiro tempo foram estendidos depois do anúncio');
const penaltyEligibility=source.slice(source.indexOf('function livePenaltyEligible('),source.indexOf('\nfunction applyLivePenalty',source.indexOf('function livePenaltyEligible(')));
if(!penaltyEligibility.includes('avg>=55')||penaltyEligibility.includes('coachTrust===100'))throw new Error('Elegibilidade de pênalti ainda exige confiança máxima');
if(source.includes('clearCareerSavesForV216TestBuild();'))throw new Error('A versão de teste ainda apaga saves na inicialização');
if(!source.includes("penalty:true,varReviewed:true"))throw new Error('Gol de pênalti ainda pode sofrer revisão indevida por impedimento');
if(!source.includes('function ccMatchMinuteModel('))throw new Error('Modelo compartilhado por minuto ausente');
if((source.match(/ccMatchMinuteModel\(/g)||[]).length<3)throw new Error('Motor automático e relógio ao vivo não compartilham o modelo');
if(!source.includes('playerGoal=playerOnPitch&&chance('))throw new Error('Overall do jogador não participa da chance individual de gol ao vivo');


for(const dir of ['topLeft','bottomLeft','center','topRight','bottomRight']){
  if(context.penaltyKickProfile({penaltySkills:{left:70,right:75,center:65}},dir,10).dir!==dir)throw new Error('Direção escolhida foi perdida antes do cálculo');
  for(let i=0;i<25;i++){
    const res=context.resolvePenaltyKick({skill:75,dir,keeper:72,keeperDir:dir,pressure:12});
    if(!['gol','defesa','para fora','trave'].includes(res.outcome))throw new Error('Resultado inválido de pênalti');
  }
}
const neutralTest=context.simulateMatchEngine('Fortíssimo','Inferior',{neutral:true});
if(neutralTest.context.homeAdvantage!==undefined&&neutralTest.context.homeAdvantage!==0)throw new Error('Campo neutro recebeu vantagem de mando');
if(neutralTest.context.neutral!==true)throw new Error('Contexto de campo neutro não foi mantido');
if(!context.simulateMatchEngine('Clube A','Clube B',{}).context.rivalry)throw new Error('Rivalidade cadastrada não foi reconhecida');
const injuryEvents=[];
context.state={id:'injury-test',season:2026,day:100,clubInjuries:{},matchEventSequence:0,p:{energy:75,fitness:75,ovr:70},careerStats:{injuries:0},news:[]};
const rec=context.ccStoreClubInjury('Clube teste',{id:'p-1',name:'Atleta Teste',ovr:72},33,'home',injuryEvents);
if(!rec||rec.status!=='injured'||!rec.durationDays||!rec.startDay)throw new Error('Registro persistente de lesão incompleto');
if(!context.ccClubPlayerUnavailable({id:'p-1'}))throw new Error('Jogador lesionado não ficou indisponível');
const availableProfile=context.matchRosterProfile('Clube teste');
if(availableProfile.xi.some(p=>p.id==='p-1'))throw new Error('Jogador lesionado permaneceu na escalação simulada');
context.state.day=100+rec.durationDays;
context.ccRecoverClubInjuries();
if(context.state.clubInjuries['p-1'].status!=='fit')throw new Error('Recuperação automática falhou');
const officialStart=source.indexOf('function officialShootoutCheck(');
const officialEnd=source.indexOf('\nfunction ',officialStart+10);
if(officialStart<0||officialEnd<0)throw new Error('Regra matemática dos pênaltis ausente');
const shootoutCode=source.slice(officialStart,officialEnd);
vm.runInContext(shootoutCode,context);
let shootout={countH:5,countA:4,h:4,a:2,stored:{m:{home:'A',away:'B'}}};
if(!context.officialShootoutCheck(shootout)||shootout.winner!=='A')throw new Error('Encerramento matemático da disputa falhou');
shootout={countH:5,countA:5,h:4,a:4,stored:{m:{home:'A',away:'B'}}};
if(context.officialShootoutCheck(shootout))throw new Error('Empate em 5 cobranças não iniciou alternadas');
shootout.countH=6;shootout.countA=6;shootout.h=6;shootout.a=5;
if(!context.officialShootoutCheck(shootout)||shootout.winner!=='A')throw new Error('Alternadas não encerraram após par decisivo');
console.log(JSON.stringify({status:'PASS',matches:350,totalGoals:sumGoals,totalShots:sumShots,clubInjuriesGenerated:injuries,varReviews,addedTimeMatches,favoriteWins,draws,upsets,penaltyDirections:5,penaltyDirectionPropagation:'PASS',shootoutMath:'PASS',injuryRecovery:'PASS',overallThresholds:'PASS',neutralField:'PASS',rivalryRecognition:'PASS',injuryRosterExclusion:'PASS',addedTimeLock:'PASS',groupedStoppage:'PASS',savePreservation:'PASS',livePenaltyEligibility:'PASS',sharedMinuteModel:'PASS'}));
