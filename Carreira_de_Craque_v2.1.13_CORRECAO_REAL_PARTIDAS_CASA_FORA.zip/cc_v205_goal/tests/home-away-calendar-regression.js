const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
function extract(name, nextName) {
  const start = html.indexOf(`function ${name}`);
  assert.notEqual(start, -1, `Função ${name} deve existir no index.html carregado pelo app`);
  const end = html.indexOf(`\nfunction ${nextName}`, start + 10);
  assert.notEqual(end, -1, `Delimitador da função ${name} deve existir`);
  return html.slice(start, end).trim();
}

const clubKeySource = extract('clubKey', 'canonicalClubName');
const enforceSource = extract('enforcePlayerHomeAwayPattern', 'makeLeagueSnapshot');
const helpersSource = [
  extract('playerIsHomeFixture', 'fixtureHasPlayer'),
  extract('fixtureHasPlayer', 'matchVenueIcon'),
  extract('matchVenueIcon', 'playerFixtureResultColor'),
].join('\n');
const context = {
  state: {
    p: { club: 'Fluminense' },
    round: 1,
    liveMatch: null,
  },
  stadiumFor: (club) => `Estádio de ${club}`,
};
vm.createContext(context);
vm.runInContext([clubKeySource, enforceSource, helpersSource].join('\n'), context);

const fixtures = [
  [{ home: 'Grêmio', away: 'Fluminense', played: true, score: [4, 1], stadium: 'Arena do Grêmio' }],
  [{ home: 'Flamengo', away: 'Fluminense', played: false, score: null }],
  [{ home: 'Coritiba', away: 'Fluminense', played: false, score: null }],
  [{ home: 'Chapecoense', away: 'Fluminense', played: false, score: null }],
  [{ home: 'Bahia', away: 'Fluminense', played: false, score: null }],
];
const playedBefore = JSON.stringify(fixtures[0][0]);
const changed = context.enforcePlayerHomeAwayPattern(fixtures, 1);
assert.equal(changed, true);
assert.equal(JSON.stringify(fixtures[0][0]), playedBefore, 'partida disputada e placar devem permanecer intactos');
assert.deepEqual(
  fixtures.map((round) => {
    const f = round[0];
    return context.playerIsHomeFixture(f, 'Fluminense') ? 'home' : 'away';
  }),
  ['away', 'home', 'away', 'home', 'away'],
  'os próximos jogos devem alternar corretamente entre casa e fora',
);
assert.equal(fixtures[1][0].home, 'Fluminense');
assert.equal(fixtures[1][0].away, 'Flamengo');
assert.equal(fixtures[1][0].stadium, 'Estádio de Fluminense');
assert.equal(fixtures[2][0].home, 'Coritiba');
assert.equal(fixtures[2][0].away, 'Fluminense');
assert.equal(context.enforcePlayerHomeAwayPattern(fixtures, 1), false, 'segunda execução deve ser idempotente');

const house = context.matchVenueIcon(true);
const plane = context.matchVenueIcon(false);
assert.match(house, /Jogo em casa/);
assert.match(html, /\.venue-icon\{[^}]*color:#fff/);
assert.match(house, /width=\"20\" height=\"20\"/);
assert.match(plane, /width=\"20\" height=\"20\"/);
assert.match(house, /M3 10\.5 12 3l9 7\.5/);
assert.match(plane, /Jogo fora de casa/);
assert.match(plane, /M12 2\.2 14\.2 9\.1 21\.6 13\.3/);
assert.match(plane, /9\.9 18\.1 9\.9 13\.1 2\.4 15\.3/);

const matchesStart = html.indexOf('function matchesView()');
const matchesEnd = html.indexOf('\nfunction ', matchesStart + 10);
const matchesView = html.slice(matchesStart, matchesEnd);
assert.match(matchesView, /if\(enforcePlayerHomeAwayPattern\(state\.fixtures,state\.round\)\)save\(\)/,
  'a própria aba Partidas deve corrigir e salvar o mando antes de desenhar o calendário');
assert.match(matchesView, /matchVenueIcon\(isHome\)/, 'cada linha do calendário deve desenhar o ícone correspondente');

console.log('OK — Partidas: casa/fora alternados, resultados preservados, ícones SVG corretos e correção aplicada na tela real.');
