# Carreira de Craque v1.62.13 — Navegação do seletor de clubes

- Corrigida a sobreposição dos escudos ampliados sobre as setas laterais.
- Setas de anterior/próximo permanecem acima da área do escudo e recebem os toques.
- Adicionado gesto de deslizar para a esquerda/direita no seletor inicial de país e clube.
- Mantidos os tamanhos destacados do Real Betis, Celta Vigo e Levante; em telas estreitas, o escudo se ajusta à área central para não bloquear a navegação.
- Cache do Service Worker atualizado para forçar a instalação dos arquivos corrigidos.
- Nenhuma regra de competição, clube, elenco ou calendário foi alterada.
