# Carreira de Craque 2.0 — Partidas Interativas

## Nova experiência de partida
- Partidas com decisões contextuais durante os 90 minutos.
- Situações variáveis de acordo com a posição do jogador e o andamento do jogo.
- Escolhas de passe, condução, drible, finalização, movimentação e ações defensivas.
- Chances de gol com diferentes tipos de finalização e consequências não garantidas.
- Eventos de bola parada, pênaltis, escanteios, faltas, cartões e comemorações.
- Frequência equilibrada: decisões em momentos relevantes, sem interromper a cada instante.
- Ações influenciadas por atributos, overall, condição física e pressão adversária.
- Registro de dribles, desarmes, passes decisivos e faltas sofridas no relatório pós-jogo.
- Jogador titular participa desde o início; reserva entra no minuto definido pela escalação.
- O primeiro tempo termina no intervalo, com ajuste tático, e o segundo tempo continua interativo.
- Retomada de uma partida interativa salva ao reabrir o jogo.

## Compatibilidade
- Preservado o motor anterior para os modos Automático, Híbrido e Decisões táticas.
- O modo Interativo 2.0 passa a ser o padrão para novas carreiras e para carreiras antigas na primeira abertura do pré-jogo após a atualização.
- Mantidos calendário, ligas, Copa do Brasil, transferências, elenco, evolução e histórico da carreira.
