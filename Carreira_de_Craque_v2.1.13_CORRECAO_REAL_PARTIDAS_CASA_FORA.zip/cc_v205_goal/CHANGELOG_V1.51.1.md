# Carreira de Craque v1.51.1 — Camisa do Brighton

- Ajustada a camisa titular do Brighton & Hove Albion para azul predominante, sem listras largas no torso.
- Adicionadas linhas verticais brancas finas somente na parte inferior da camisa e detalhes discretos nas mangas, seguindo a imagem de referência enviada.
- Aplicado o padrão nas prévias grandes e pequenas da camisa.
- Nenhuma outra equipe, competição ou fundo foi alterado nesta atualização.
