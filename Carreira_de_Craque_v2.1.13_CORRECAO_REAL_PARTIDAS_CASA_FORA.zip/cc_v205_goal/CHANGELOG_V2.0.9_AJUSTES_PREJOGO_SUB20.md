# v2.0.9 — Ajustes da Central de Pré-jogo

- Removidos os controles “Modo de partida” e “Plano tático” da Central de pré-jogo.
- Removido o campo visual e a escalação tática dessa tela.
- Carreiras Sub-20 usam estádios de base cadastrados e escala de arbitragem própria.
- VAR indicado como não utilizado nas partidas Sub-20.
- Carreiras profissionais mantêm estádios, árbitros e VAR profissionais.
- Preservado o botão de confirmação e o fluxo de início da partida.
