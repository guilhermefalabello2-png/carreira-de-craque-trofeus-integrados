# Carreira de Craque v2.1.12 — Correção de mando e ícones

- Corrigida a inversão ao alternar o mando de campo nas partidas futuras do jogador.
- Partidas não disputadas passam a alternar corretamente entre casa e fora, preservando jogos já realizados.
- Identificação de casa/fora usa comparação de nomes canônicos do clube.
- Ícone de casa substituído por SVG minimalista de residência.
- Ícone de fora substituído por SVG de aeronave em vista superior, com fuselagem, asas e cauda.
- Os mesmos ícones são exibidos também nas partidas da Copa do Brasil.
- Calendário, confrontos, resultados e simulação não foram recriados.
