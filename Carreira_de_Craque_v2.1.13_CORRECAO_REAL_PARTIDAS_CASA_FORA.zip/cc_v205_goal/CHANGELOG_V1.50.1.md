# v1.50.1 — Elencos da Série C associados

- Associados os 440 jogadores informados pelo usuário aos 20 clubes da Série C.
- Preservados nome, posição e número da camisa conforme a lista recebida.
- Overall e atributos são estimativas internas de gameplay, não ratings oficiais.
- Série D não foi criada.
