# v1.62.70a — Identificação das ligas na escolha de país e clube

- Em “Escolher País e Clube”, Inglaterra agora aparece como “Inglaterra - Premier League (Profissional)”.
- Espanha agora aparece como “Espanha - LaLiga (Profissional)”.
- Ajustadas as mensagens de início para identificar explicitamente a liga profissional correspondente.
- Mantida a estrutura de clubes, elencos, calendários e demais sistemas da versão-base v1.62.70.
