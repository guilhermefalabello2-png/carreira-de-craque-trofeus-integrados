# v2.0.3 — Correção da comemoração por participação em gol

- A mensagem “Você acabou de participar de um gol!” agora só aparece quando o atleta controlado marca ou dá assistência.
- Gols marcados por companheiros continuam atualizando o placar e a narração, mas não ativam a comemoração individual do jogador.
- A elegibilidade da comemoração individual passou a usar uma sinalização própria, separada dos gols gerais da equipe.
- Nenhuma outra mecânica da partida foi alterada intencionalmente.
