# Carreira de Craque v1.62.14 — Isolamento das ligas por país

## Correções
- A tela **Ligas > Brasil** não reutiliza mais `state.divisions` de carreiras estrangeiras. Agora usa exclusivamente os clubes brasileiros da divisão correspondente, preservando as divisões atualizadas de carreiras brasileiras.
- A tela **Ligas > Inglaterra** abre a Premier League inglesa independente quando a carreira atual é da Espanha. Assim, uma carreira na LaLiga não altera o conteúdo da Premier League.
- A visualização da Premier League durante uma carreira inglesa continua ligada à competição da carreira.
- A tela da LaLiga da carreira espanhola permanece intacta.

## Teste de regressão
- Carreira LaLiga ativa + Ligas > Brasil: 20 clubes brasileiros, sem clubes espanhóis.
- Carreira LaLiga ativa + Ligas > Inglaterra: Premier League, sem tabela espanhola.

## Observação de compatibilidade
- Carreiras brasileiras continuam usando os participantes dinâmicos de `state.divisions` para respeitar acessos e rebaixamentos. A proteção exclui somente carreiras estrangeiras.
