# v2.1.8 — Correção do mando de campo

- Alternância do mando do clube do jogador: casa, fora, casa, fora, nas rodadas futuras da liga ativa.
- Correção aplicada também ao recuperar partidas antigas e trocar de clube/competição, preservando jogos já disputados.
- Copa do Brasil mantém sorteio aleatório de mandante/visitante em cada confronto, inclusive na final.
- Final da Copa do Brasil no Estádio Nacional Mané Garrincha.
- Migração da Copa preserva confrontos e placares existentes e atualiza o estádio da final.
