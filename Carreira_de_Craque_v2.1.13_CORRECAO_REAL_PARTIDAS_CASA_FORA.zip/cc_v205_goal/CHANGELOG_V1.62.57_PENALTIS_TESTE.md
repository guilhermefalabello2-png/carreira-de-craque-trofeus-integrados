# Carreira de Craque v1.62.57 — Área de teste de pênaltis

- Adicionada à janela **Escolher País e Clube** uma área de testes com uma final especial de placar oficial fixo em 0 x 0.
- A final de teste permite escolher qual equipe inicia a disputa.
- Cobranças sequenciais com revelação de GOL/ERRO e desempate em morte súbita.
- Na vez do usuário, as opções ficam lado a lado na ordem **ESQUERDA | MEIO | DIREITA**, com probabilidades individuais e cores por faixa (verde a partir de 70%, laranja de 41% a 69%, vermelho até 40%).
- Adicionado treino **Pênaltis**: cada sessão aumenta em 2 pontos percentuais a precisão de cada direção, com limites de 5% a 95%.
- O resultado da disputa de teste não altera carreira, estatísticas, competições ou placar oficial.

Base: v1.62.56 — Correção da tela preta.
