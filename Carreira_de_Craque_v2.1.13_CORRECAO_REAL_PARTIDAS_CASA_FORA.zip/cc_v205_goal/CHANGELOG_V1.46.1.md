# Carreira de Craque v1.46.1 — Escudos da Série C

- Adicionados mapeamentos de escudos transparentes para os clubes da Série C que não possuíam arte local.
- Figueirense, Paysandu e Santa Cruz reutilizam os SVGs locais já existentes no projeto.
- Os escudos são exibidos pela função central `crest()`, portanto aparecem nas tabelas, partidas e demais telas que reutilizam essa função.
- Atualizado o número interno da versão para invalidar estado de cache antigo da aplicação.

## Fonte e observação

Os PNGs externos vêm da coleção de escudos da Série C 2026 do FootyLogos: https://www.footylogos.com/pt-br/competition/brasileirao-serie-c. Os clubes que usam URL externa precisam de conexão à internet para carregar o escudo; o fallback visual existente permanece ativo caso um recurso remoto falhe.
