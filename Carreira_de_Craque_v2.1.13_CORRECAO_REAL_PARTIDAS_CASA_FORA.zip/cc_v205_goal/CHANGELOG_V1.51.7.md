# v1.51.7 — Recuperação de calendário para todas as ligas
- Generalizada a recuperação do calendário: não fica mais restrita aos clubes ingleses.
- Ao avançar a temporada, verifica se o calendário e a tabela contêm o clube atual.
- Reconstrói a estrutura da competição brasileira ou inglesa conforme o clube reconhecido, permitindo sair do bloqueio causado por calendário ausente ou associação perdida.
- Não inventa resultados para partidas que não existem no save. Se for necessário reconstruir a tabela, os resultados ausentes não podem ser restaurados automaticamente.
