# v1.63.10 — IDs nas logos das competições

- Adicionados IDs HTML estáveis às imagens das logos de todas as competições cadastradas.
- Incluídos `data-competition-logo-id`, `data-competition-id` e `data-logo-key` diretamente nas imagens.
- Aplicada a mesma identificação aos troféus exibidos na Sala de Troféus, com ID único por temporada.
- Mantido o registro central de competições e os caminhos de imagem existentes.
