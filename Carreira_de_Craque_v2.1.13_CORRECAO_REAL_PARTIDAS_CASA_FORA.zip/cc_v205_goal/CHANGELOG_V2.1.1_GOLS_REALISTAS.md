# Carreira de Craque v2.1.1 — GOLS REALISTAS

## Motor de partidas
- Rebalanceada a frequência de sequências ofensivas e criação de finalizações.
- Melhorada moderadamente a precisão e a conversão, mantendo limites para evitar gols automáticos.
- Qualidade de ataque, meio-campo, finalização, defesa, goleiro, estrelas, tática e condição física continuam influenciando o resultado.
- Preservadas defesas, chutes para fora, eventos, estatísticas e geração dinâmica do placar.
- Nenhum resultado foi predeterminado.

## Compatibilidade
- Alteração localizada em `simulateMatchEngine`; demais telas e sistemas foram mantidos.
