# Carreira de Craque v1.62.37 — Serie A TIM no seletor

- Identificação da opção italiana no seletor como **Itália — Serie A TIM (Profissional)**.
- Texto de confirmação deixa explícito que a carreira começa no elenco profissional da Serie A TIM.
- Mantidos os 20 clubes italianos, escudos, calendário e demais ligas.
- Nenhuma alteração no motor de partidas ou nos elencos.
