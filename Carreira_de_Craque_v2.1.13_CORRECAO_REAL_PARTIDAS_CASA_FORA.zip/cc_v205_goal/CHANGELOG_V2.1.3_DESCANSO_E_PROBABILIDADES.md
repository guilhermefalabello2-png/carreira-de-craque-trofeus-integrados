# Carreira de Craque v2.1.3

- Incluído pedido de descanso pré-partida, com avaliação baseada em condição física, profundidade do elenco e importância do compromisso.
- Pedido duplicado bloqueado para a mesma partida; descanso aceito impede escalação e recupera condição física.
- Exibidas probabilidades estimadas junto às opções de decisão no modo interativo; a resolução usa o mesmo valor probabilístico apresentado.
- Posse de bola nas estatísticas finais normalizada para inteiros complementares que somam exatamente 100%.
- Mantidos os arquivos e recursos anteriores do projeto.
