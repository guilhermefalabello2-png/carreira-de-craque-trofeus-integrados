# Carreira de Craque — projeto Android (Capacitor)

Este pacote contém o jogo e a configuração para gerar um APK Android próprio usando Capacitor 6.
O fluxo de seleção de arquivos usa o suporte nativo da WebView/Bridge do Capacitor para `<input type="file">`.

## Gerar APK pelo celular usando GitHub Actions

1. Crie um repositório no GitHub e envie **todo o conteúdo deste ZIP** para a raiz do repositório.
2. Abra a aba **Actions** do repositório.
3. Se o GitHub pedir, habilite Actions.
4. Execute o workflow **Gerar APK Android** em **Run workflow**.
5. Aguarde o término do job e abra o artefato `Carreira-de-Craque-APK-debug`.
6. Baixe o ZIP do artefato, extraia `app-debug.apk` e instale no Android.

O APK `debug` é para teste. Para distribuição permanente, será necessário gerar e guardar uma chave de assinatura e compilar uma versão `release`.

## Observações

- O projeto não inclui um APK pré-compilado: a compilação é feita pelos servidores do GitHub Actions.
- A geração depende da disponibilidade das dependências npm/Android nos repositórios oficiais.
- O seletor nativo deve ser testado no APK instalado. A configuração Capacitor usa a ponte Android padrão; não é possível garantir o comportamento do conversor antigo.
- O arquivo HTML do jogo foi mantido sem alterações nesta preparação.
