# v1.63.5 — DATAPACKS / PATCHES
- Menu inicial: novo botão “Colocar Patch”.
- Importação de pacotes ZIP com manifesto patch.json.
- Escudos importados são associados por ID permanente do clube.
- Imagens dos patches são armazenadas em IndexedDB, separadas dos saves e do jogo.
- O pacote principal deixa de carregar a biblioteca local de escudos de clubes; nomes e jogadores permanecem no jogo.
- Formato do manifesto: {"format":"CC-PATCH","version":1,"name":"Nome do patch","crests":{"BRA-FLAMENGO":"escudos/flamengo.webp"}}.
- Imagens aceitas: PNG, JPEG, WebP e SVG; limite de 2 MB por escudo.
