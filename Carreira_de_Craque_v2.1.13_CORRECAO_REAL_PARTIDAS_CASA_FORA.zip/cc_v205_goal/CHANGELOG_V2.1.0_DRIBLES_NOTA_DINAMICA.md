# Carreira de Craque v2.1.0 — Continuidade das fintas e nota dinâmica

- Toda finta/drible bem-sucedido (pedalada, corte seco, caneta, giro e drible no goleiro) abre uma segunda decisão para continuar a jogada.
- Após superar o marcador, o jogador pode finalizar, tocar para um companheiro, avançar conduzindo ou tentar outra finta.
- A opção de tentar outra finta permite escolher caneta, pedalada, corte seco ou giro; se funcionar, a sequência pode continuar.
- Dribles malsucedidos mantêm a consequência de perda da posse.
- Nota ao vivo passa a considerar passes certos e errados, fintas certas e erradas, passes decisivos, desarmes, finalizações no alvo, boas movimentações, defesas e erros.
- A nota atual também aparece nas telas de resolução das jogadas e continua alimentando a lógica de substituição por baixo desempenho.
- O relatório final registra os novos indicadores individuais.
- Preservados o calendário, ligas, elencos, transferências, partidas, pré-jogo e demais sistemas existentes.
