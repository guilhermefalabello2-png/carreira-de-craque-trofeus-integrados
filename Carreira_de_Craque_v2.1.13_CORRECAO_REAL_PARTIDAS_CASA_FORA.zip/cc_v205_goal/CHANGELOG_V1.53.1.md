# v1.53.1 — Correção de quota de armazenamento

- Armazenamento das ligas europeias separado por competição, em vez de um único item localStorage gigante.
- Escrita compacta de calendários e placares como fallback.
- A criação da carreira Sub-20 não deve falhar por exceder a quota do item cc_european_leagues_v119.
