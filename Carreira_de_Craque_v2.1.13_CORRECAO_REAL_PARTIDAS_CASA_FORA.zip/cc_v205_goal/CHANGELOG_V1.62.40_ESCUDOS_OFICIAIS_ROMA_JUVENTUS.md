# v1.62.40 — Escudos oficiais da Roma e Juventus

- Roma: substituído o SVG genérico por arquivo vetorial do escudo oficial atual da AS Roma.
- Juventus: substituído o SVG genérico por arquivo vetorial da identidade oficial atual da Juventus (monograma J preto).
- Atualizado o cache do service worker para forçar a atualização dos escudos após a publicação.
- Nenhuma outra liga, elenco, carreira ou mecânica foi alterada.

Fontes dos arquivos: FootyLogos, páginas de identidade dos clubes AS Roma e Juventus. Os links são servidos externamente.
