# v2.1.10 — Correção do calendário da aba PARTIDAS

- Ícones SVG minimalistas de mando de campo adicionados diretamente às linhas do calendário: casa para mandante e avião para visitante.
- Aplicação baseada no clube do jogador e no mando real de cada confronto, sem depender de uma liga específica.
- Resultados do clube do jogador identificados corretamente como VITÓRIA, EMPATE ou DERROTA, inclusive quando atua como visitante.
- Placar e status recebem verde, amarelo ou vermelho conforme o resultado do clube do jogador.
- Copa do Brasil recebe os mesmos ícones e a identificação colorida do resultado, preservando o destaque visual da competição.
- Mantidos confrontos, placares, datas, escudos, nomes dos clubes, simulação e classificação.
- Validação: sintaxe JavaScript do aplicativo aprovada; seis cenários de mando/resultado (casa e fora) e partida não disputada aprovados.
