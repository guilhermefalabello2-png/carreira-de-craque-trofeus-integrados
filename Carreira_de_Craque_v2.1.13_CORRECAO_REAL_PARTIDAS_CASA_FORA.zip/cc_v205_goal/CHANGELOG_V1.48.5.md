# Carreira de Craque v1.48.5 — Seletor visual de destino

- A seção “Escolha seu destino” no Mercado agora usa uma tela de seleção visual inspirada em “Escolher país e clube”.
- Navegação por escudos, nomes, estrelas e contador de clubes.
- Inclui clubes da Série A, Série B, Série C e Premier League.
- Clubes Sub-20 não aparecem neste seletor.
- A lista mostra todos os clubes, mas as regras de contato do empresário continuam bloqueando negociações fora do nível permitido.
- Mantidos os demais fluxos do Mercado e os dados da carreira.
