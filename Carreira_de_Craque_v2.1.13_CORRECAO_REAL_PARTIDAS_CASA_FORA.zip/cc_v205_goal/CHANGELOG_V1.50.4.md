# Carreira de Craque v1.50.4 — Ajuste fino da camisa do Fluminense

- Corrigido o padrão do uniforme titular do Fluminense nas duas representações de camisa do jogo.
- Listras grená e verdes mais largas e contínuas, com filetes brancos bem mais finos entre elas.
- As listras da camisa frontal agora começam na região superior do tronco e seguem visualmente até a gola, respeitando o recorte do uniforme.
- Mantidos escudo, número, nome, cores e os demais uniformes.
