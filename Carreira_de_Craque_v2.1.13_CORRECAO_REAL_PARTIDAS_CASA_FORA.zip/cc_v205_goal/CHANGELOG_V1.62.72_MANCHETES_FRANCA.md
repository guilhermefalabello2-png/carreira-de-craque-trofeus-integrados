# Carreira de Craque v1.62.72 — Manchetes da França

- Adicionado o veículo francês L'Équipe ao sistema de coletivas e manchetes pós-jogo.
- Três jornalistas franceses integrados à rotação de perguntas e assinatura das matérias: Vincent Duluc, Damien Degorre e Hervé Penot.
- Manchetes francesas geradas conforme o placar real da partida, incluindo empates e clássicos.
- A identidade L'Équipe só é ativada quando a carreira do jogador está vinculada à França (chave da Ligue 1, país França ou clube atual da Ligue 1).
- As identidades de imprensa das demais ligas foram preservadas.
- Nenhum resultado é inventado: a matéria usa placar, eventos e participação registrados na partida.
