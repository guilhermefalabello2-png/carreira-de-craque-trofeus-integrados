# Carreira de Craque v1.53.6 — Classificação e Legado consistentes

## Diagnóstico comparativo
A tabela durante a simulação chama `sortStandings(state.table, state.fixtures)` com `state.fixtures` agrupado em 38 rodadas (array 2D). O fechamento da temporada e a validação do Legado chamam a mesma função com partidas achatadas (array 1D). A implementação antiga percorria diretamente `fixtures`, esperando objetos de partida; ao receber arrays de rodadas, não via partidas e ignorava o confronto direto. Em empates nos critérios anteriores, a tabela exibida podia colocar um clube abaixo enquanto a classificação consolidada o colocava em primeiro e validava o título.

## Correção
`sortStandings` agora normaliza sua entrada com `fixtures.flat()` antes de aplicar os critérios. O cálculo de pontos, vitórias, saldo, gols pró, confronto direto, fair play e ordem alfabética foi preservado; a mesma regra passa a funcionar para ambos os formatos de entrada. O Sub-20 mantém seu cálculo de tabela separado.

## Teste de regressão
Foi adicionado um cenário de empate estatístico em que o confronto direto decide o primeiro lugar. O teste exige que fixtures agrupados por rodada e fixtures achatados produzam exatamente a mesma ordem. Também são executados os testes de Legado, classificação, promoção/rebaixamento e sintaxe.
