# Carreira de Craque v1.48.3 — Buscar Clube

- No Mercado, a experiência principal passa a ser **Buscar clube**, substituindo a seção de propostas recebidas como foco da tela.
- O jogador escolhe o clube de destino em uma lista com equipes brasileiras cadastradas e clubes da Premier League presentes na base.
- A classificação por estrelas do clube determina a compatibilidade com a rede de contatos do empresário.
- Empresário de 1 estrela: clubes até 2 estrelas; 2 estrelas: até 3; 3 estrelas: até 3,5; 4 estrelas: até 4; 5 estrelas: qualquer clube.
- Clubes fora do alcance exibem **EMPRESÁRIO SEM CONTATO** e não permitem iniciar a negociação.
- Para clubes acessíveis, o jogador informa sua oferta e recebe uma tentativa com probabilidade calculada entre 1% e 100%, considerando oferta, empresário, overall, reputação e exigência do clube.
- Uma tentativa bem-sucedida gera uma proposta formal que ainda precisa ser analisada pelo jogador; a transferência não acontece sem sua decisão.
- Mantidos o sistema de contratos, o fluxo de aceite/recusa das propostas, os dados de carreira e os escudos existentes.
