# Carreira de Craque v2.1.5 — Motor de partidas e pênaltis

## Implementado nesta atualização
- Evolução do `simulateMatchEngine` existente (sem criar um segundo motor).
- Avaliação ofensiva e defensiva por setores, meio-campo, goleiro, estrelas, prontidão, fadiga e tática.
- Vantagem de mando moderada, desativável em campo neutro.
- Contexto de rivalidade consultado pelo cadastro existente.
- Efeito moderado de desvantagem numérica após expulsões.
- Bônus de overall aplicado uma única vez à chance-base de conversão de cada finalização, conforme a tabela especificada (0/2/4/6/8/10 pontos percentuais).
- Eventos de gol agora identificam o finalizador e o overall considerado; estatísticas de finalização, gol e defesa seguem a mesma cadeia de simulação.
- Disputa interativa do jogador ampliada para cinco zonas de chute; goleiro recebe uma direção de reação e pode defender.
- Mantida a checagem matemática de encerramento da disputa de pênaltis e a sequência de cobranças alternadas.

## Limitações ainda não implementadas nesta entrega
A especificação completa inclui subsistemas extensos que exigem integração adicional com persistência, calendário, escalações e interface: lesões para todos os atletas e recuperação global, VAR com revisão e reversão transacional, acréscimos por duração de interrupções, narração centralizada em tempo real, estatísticas ampliadas/histórico, rivalidades tipadas e testes de regressão de todas as competições. Esses itens não são declarados como concluídos nesta versão.

## Validação
- Verificação sintática do JavaScript principal com `node --check`.
- Teste automatizado de consistência do motor e da resolução de pênaltis incluído em `tests/match-engine-regression.js`.
