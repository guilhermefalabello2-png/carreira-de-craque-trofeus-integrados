# Carreira de Craque v1.62.70g — Correção dos escudos da Ligue 1

- Corrigida a exibição dos escudos no seletor de país e clube e em outros pontos que usam a função central de escudos.
- Os 18 escudos da Ligue 1 agora são incorporados diretamente no HTML como imagens PNG em Data URI, evitando falhas de caminho relativo, cache ou carregamento offline.
- Mantidos nomes, ordem, elencos, estrelas, calendário, partidas e demais funcionalidades da base v1.62.70.
- Cache do PWA atualizado para forçar a instalação da correção.
