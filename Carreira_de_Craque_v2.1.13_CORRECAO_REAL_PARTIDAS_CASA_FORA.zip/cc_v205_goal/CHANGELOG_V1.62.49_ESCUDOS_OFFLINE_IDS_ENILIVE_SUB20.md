# v1.62.49 — Escudos offline, IDs Serie A Enilive e logo Sub-20

- Restaurada a pasta completa `assets/` que havia ficado de fora do ZIP v1.62.48.
- O renderizador prioriza escudos SVG/PNG locais antes de tentar URLs externas.
- Adicionados IDs estáveis `ita_*` aos 20 clubes da Serie A Enilive.
- Logo PNG do Brasileirão Sub-20 restaurada no caminho esperado e incluída no cache offline.
- Service worker atualizado: arquivos locais entram no cache de instalação; logos remotas de imagem são armazenadas após o primeiro carregamento online para uso offline posterior.
- Cache atualizado para forçar a instalação dos recursos da nova versão.

Nota: escudos locais já presentes no pacote funcionam imediatamente offline. Imagens de clubes que ainda dependem de host externo precisam ser carregadas uma vez com internet para entrar no cache.
