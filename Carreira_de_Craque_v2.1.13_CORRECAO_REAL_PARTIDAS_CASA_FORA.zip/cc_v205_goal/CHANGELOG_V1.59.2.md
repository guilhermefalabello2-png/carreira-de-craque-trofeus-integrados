# Carreira de Craque v1.59.2 — Copa do Brasil visível no calendário

- Corrigida a integração visual da Copa do Brasil no calendário: o bloco agora aparece tanto na tela Início quanto em Partidas, dentro da área de calendário da temporada.
- O bloco exibe escudo vetorial minimalista, temporada, fase atual, quantidade de participantes, situação do clube e confrontos.
- Incluída lista expansível com todos os confrontos da fase atual, para que a Copa continue visível mesmo quando o clube do usuário ainda não tiver um jogo naquela fase.
- Mantidos os dados da competição dentro do save da carreira.
- Aplicada limpeza única das carreiras salvas nesta versão, conforme autorização permanente do usuário. A limpeza atinge apenas dados de carreira; não remove elencos, clubes, escudos ou arquivos do jogo.
