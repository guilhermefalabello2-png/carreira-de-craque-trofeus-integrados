# v1.53.18 — Estante de Conquistas
- Reconstruída do zero a tela Conquistas como uma estante visual de troféus.
- Cada troféu mostra somente a imagem e o ano conquistado; sem nome da competição, clube, estatísticas, transferências ou lista de temporadas.
- Somente conquistas com registro validado e finalizado podem aparecer. Temporadas sem título confirmado não geram troféu.
- Nenhuma lógica de partidas, placares, calendário ou avanço de rodadas foi alterada.
- Base utilizada: v1.53.16, versão estável confirmada pelo usuário.
