# Carreira de Craque v1.61.3 — Respostas coerentes nas coletivas

- Respostas das entrevistas agora são construídas conforme o resultado real da partida: vitória, empate ou derrota.
- Perguntas sobre gols, assistências, cartões, expulsões e atuação individual recebem respostas relacionadas ao acontecimento registrado.
- Jogador que não entrou em campo recebe respostas sobre banco, preparação e disputa por minutos.
- Respostas provocadoras após derrota não comemoram nem insinuam vitória; reconhecem o resultado e projetam uma reação.
- Manchete de atuação de gala só é usada quando o time do jogador venceu e ele marcou pelo menos dois gols.
- Mantidos os estilos de resposta: humilde, confiante, provocadora, sincera e profissional.
