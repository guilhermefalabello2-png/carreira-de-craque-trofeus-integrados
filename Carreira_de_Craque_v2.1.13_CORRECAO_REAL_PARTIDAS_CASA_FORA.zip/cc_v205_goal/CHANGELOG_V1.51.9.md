# v1.51.9 — Classificação e pontuação

- Recalcula a tabela a partir dos placares salvos ao fim de cada rodada, evitando depender apenas de contadores incrementais.
- Cada vitória soma 3 pontos, empate 1 e derrota 0.
- Aplica a reconstrução à liga da carreira e às tabelas paralelas nacionais.
- Ordena a classificação novamente após a reconstrução: pontos, vitórias, saldo e gols pró, seguidos dos critérios já existentes.

Nota: esta correção não consegue reconstruir resultados que já tenham sido perdidos do save; ela recalcula a tabela usando os placares que ainda estão salvos no calendário.
