# Carreira de Craque v1.56.0 — Motor por Eventos

## Referência observacional
A gravação fornecida foi analisada em quadros da partida e do intervalo. Foram observados: relógio em andamento, placar evolutivo, posse e finalizações durante o jogo, formações (ex.: 4-4-2), onze escalados, banco, condição física e comandos táticos NORMAL / PRESSÃO / ATAQUE / DEFESA. A referência foi usada apenas para orientar o comportamento; nenhum código proprietário do Brasfoot foi copiado.

## Alterações
- O Modo Realismo usa `simulateMatchEngine` como motor central baseado em posses por minuto, ataques, finalizações, bolas no alvo, defesas e gols.
- O placar e as estatísticas de equipe são retornados pelo mesmo objeto de simulação; não há sorteio separado de estatísticas pós-jogo.
- Força por setor usa ataque, meio, defesa, goleiro, overall, profundidade do elenco e estrelas do clube; mando e tática também influenciam.
- Cartões vermelhos raros reduzem a força da equipe pelo restante da partida.
- Calendário profissional, Sub-20, ligas brasileiras paralelas, ligas europeias e partida do atleta chamam o mesmo motor quando REALISMO está ativado.
- REALISMO desativado preserva o caminho anterior.
- Eventos de gol carregam lado, minuto, marcador e assistência para manter a atribuição de gols correta.
- Relatório pós-jogo recebe `teamStats` do mesmo objeto que determinou o placar.

## Testes
`tests/realism-mode-regression.js`: 10.000 partidas por cenário, seis cenários, 60.000 partidas no total. O teste verifica ainda consistência de placar, finalizações, chutes no alvo e posse.
`tests/event-engine-integration.js`: confirma os pontos de entrada de todas as competições e o uso das estatísticas do motor no relatório.

## Limites conhecidos
Os testes estatísticos usam elencos sintéticos controlados para calibrar o motor. Não substituem uma temporada completa no Android com os elencos reais. A gravação de referência não fornece acesso ao código-fonte do Brasfoot; o APK foi tratado como referência observacional, sem engenharia reversa ou cópia de implementação.
