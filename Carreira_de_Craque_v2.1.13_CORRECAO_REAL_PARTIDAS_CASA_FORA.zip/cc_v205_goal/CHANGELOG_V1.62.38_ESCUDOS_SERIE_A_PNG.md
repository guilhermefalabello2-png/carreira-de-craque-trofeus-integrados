# Carreira de Craque v1.62.38 — Escudos Serie A TIM

- Atualizados os 20 escudos da Serie A TIM para URLs diretas de PNG transparente.
- Substituídos formatos JPG, WebP, SVG e endereços que não apontavam diretamente para uma imagem.
- Atalanta usa a identidade atualizada em 2026.
- Mantidos clubes, nomes, estrelas, calendário, elencos e demais ligas.
- Cache PWA atualizado para recarregar os escudos.

Fonte dos PNGs: FootyLogos, coleção Serie A 2026/27.
