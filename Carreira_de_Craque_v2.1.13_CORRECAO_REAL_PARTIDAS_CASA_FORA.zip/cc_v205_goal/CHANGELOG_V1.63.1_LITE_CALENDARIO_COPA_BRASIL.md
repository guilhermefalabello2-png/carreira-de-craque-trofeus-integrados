# Carreira de Craque v1.63.1 LITE — Calendário integrado e Copa do Brasil

- Aplicado o calendário de rodadas do Brasileirão de 29/03 a 02/12, conforme datas fornecidas.
- O mesmo calendário de rodadas passa a ser usado pelas ligas europeias jogáveis; clubes europeus não são inscritos na Copa do Brasil.
- Copa do Brasil com datas fixas: 1ª fase 08/04; 2ª fase 06/05; oitavas 08/07 e 15/07; quartas 09/09 e 16/09; semifinal 04/11 e 11/11; final única 06/12.
- Corrigida a geração das fases seguintes para usar datas oficiais fixas, evitando que o chaveamento avance para datas sem calendário ou fique preso nas quartas.
- A temporada não é considerada encerrada após a R38 se o clube do jogador ainda estiver vivo na Copa do Brasil; isso impede a finalização prematura e o crédito indevido do título do Brasileirão.
- Após a R38, o calendário continua permitindo avançar até a final da Copa em 06/12.
- Mantidos o formato de 64 participantes, as regras de classificação, pênaltis e os jogos da Copa destacados em azul.
