# v1.63.2 LITE — Escudos brasileiros offline

- Integrados os escudos dos 20 clubes da Série A e dos 20 clubes da Série B fornecidos pelo usuário.
- Imagens convertidas para WebP, redimensionadas para no máximo 224×224 e otimizadas para manter a versão LITE.
- Interface e registro de clubes priorizam os arquivos locais, sem depender de URLs externas para esses 40 clubes.
- Mantidos os recursos existentes das demais ligas e divisões.
- Nenhuma carreira salva, elenco, tabela, calendário ou regra de competição foi apagada ou alterada.
