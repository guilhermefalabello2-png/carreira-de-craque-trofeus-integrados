# Carreira de Craque v2.0.5 — Substituição, nota ao vivo e tela cheia

- Adicionada chance de substituição por baixo rendimento a partir dos 55 minutos, com probabilidade maior conforme a nota cai.
- A nota do jogador passa a aparecer em tempo real na tela PARTIDA EM ANDAMENTO.
- A nota final usa a mesma fórmula da avaliação ao vivo, sem variação aleatória no apito final.
- Removida da interface a exibição dos acréscimos previstos do primeiro e do segundo tempo; o relógio e os acréscimos continuam funcionando.
- A tela PARTIDA EM ANDAMENTO agora ocupa toda a área disponível do celular.
- Preservadas as mecânicas e correções da versão 2.0.4.

# Histórico de atualizações — Carreira de Craque

## v2.0.6 — Gol com apresentação de transmissão
- Todo gol durante a partida interativa abre uma tela especial para qualquer um dos dois clubes.
- Exibe o escudo cadastrado do clube, a chamada “GOL DO [CLUBE]!”, autor e minuto do gol.
- Inclui uma descrição curta da jogada; gols de assistência e de pênalti também identificam o autor corretamente.
- Se os dois times marcarem no mesmo minuto, os avisos aparecem em sequência antes de o relógio continuar.
- O botão CONTINUAR PARTIDA fecha a apresentação e retoma o jogo.
- Preservadas as mecânicas anteriores da versão 2.0.5.

## v2.0.2 — Partidas mais realistas e fluxo de início
- Equilíbrio de gols e ataques das duas equipes durante o relógio corrido, com volume de chances ajustado para uma partida mais realista.
- Separação entre avançar o calendário até a partida e começar o jogo manualmente.
- Botão COMEÇAR JOGO em Início e Partidas na data correta.
- Proteção contra fechamento acidental da partida em andamento.
- Intervalo com apenas o botão COMEÇAR SEGUNDO TEMPO.
- Relógio 25% mais rápido (750 ms por minuto simulado).

## v2.0.1 — Relógio correndo e acréscimos
- Relógio contínuo com pausa nas decisões.
- Acréscimos variáveis de 3, 5 ou 7 minutos por tempo.

## v2.0.0 — Partidas interativas
- Sistema de decisões durante a partida com 13 categorias.

## v2.0.3 — Correção da comemoração por participação em gol
- A comemoração individual agora é acionada somente após gol ou assistência do atleta controlado.
- Gol de companheiro não é mais tratado como participação direta do jogador.


## v2.0.4 — Ritmo imprevisível das participações
- Removido o agendamento de decisões por faixas fixas de minutos.
- Oportunidades avaliadas minuto a minuto por probabilidade dinâmica, aumentando gradualmente enquanto não surge uma situação.
- Intervalos de respiro aleatórios após decisões, evitando ciclos repetitivos.
- Ajuste aplicado também após decisões e no início do segundo tempo.

## v2.0.7 — Pré-jogo com fluxo completo
- Início: botão único **IR A PARTIDA** no próximo compromisso.
- Pré-jogo completo com confronto, escudos, estádio, data, horário, transmissão, árbitro e VAR.
- O jogo só começa ao tocar em **COMEÇAR JOGO**; se necessário, o calendário avança até o dia marcado e retorna ao pré-jogo.
- Mantidas escolhas de escalação, modo e plano tático.
