# v2.0.2 — Partidas mais realistas e fluxo de início

## Correções e melhorias
- Aumentada a participação ofensiva das duas equipes durante o relógio corrido, com ataques, finalizações, defesas e gols independentes para cada lado, com frequência ajustada para aproximar o volume de chances de uma partida realista.
- Corrigido o fluxo de calendário: **AVANÇAR ATÉ O JOGO** apenas leva o calendário até a data da partida; não inicia a partida automaticamente.
- Adicionado o botão **COMEÇAR JOGO** nas telas Início e Partidas quando chega o dia do confronto.
- A confirmação do pré-jogo agora salva a escalação e a preparação sem iniciar a partida automaticamente.
- A sessão da partida fica protegida contra fechamento acidental pelo X ou toque fora da janela enquanto estiver em andamento.
- No intervalo, removidas as opções táticas e mantido somente **COMEÇAR SEGUNDO TEMPO**.
- Relógio acelerado de 1.000 ms para 750 ms por minuto simulado.

## Preservação
- Mantidas as 13 categorias de situações interativas, consequências, estatísticas, competições, calendário e demais sistemas existentes.
- Nenhuma atualização do GitHub ou compilação de APK foi realizada nesta etapa; esta é uma versão ZIP para teste.
