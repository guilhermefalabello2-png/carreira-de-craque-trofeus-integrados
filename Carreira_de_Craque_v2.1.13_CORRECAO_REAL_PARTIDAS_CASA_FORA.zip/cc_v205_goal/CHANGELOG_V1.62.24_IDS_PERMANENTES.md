# v1.62.24 — Sistema de IDs permanentes

- Criado cadastro central `CLUB_ID_REGISTRY` para todos os clubes das competições brasileiras e europeias cadastradas.
- Cada clube recebe ID determinístico e permanente, independente de liga, divisão ou promoção/rebaixamento.
- Cadastro reúne nome oficial, país, liga, referência de escudo, uniforme disponível, elenco e reputação/estrelas.
- Elencos retornados por `rosterForClub` passam a carregar `clubId`, mantendo os IDs individuais dos atletas.
- Criados IDs próprios para equipes Sub-20, vinculados ao clube profissional por `parentId`.
- `professionalClubId` passa a consultar o cadastro central.
- Mantidos nomes de exibição e formatos legados para compatibilidade com carreiras existentes; nenhum save foi apagado nesta atualização.
- IDs gerados por código determinístico e não por posição na lista: adicionar clubes ou mudar a ordem das ligas não altera os IDs já existentes.
