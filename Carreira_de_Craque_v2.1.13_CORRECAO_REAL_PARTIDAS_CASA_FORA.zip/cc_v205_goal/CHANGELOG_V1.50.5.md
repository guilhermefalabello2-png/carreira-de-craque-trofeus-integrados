# Carreira de Craque v1.50.5

- Corrigida a posição exibida no encerramento do Brasileirão Sub-20.
- A posição e os pontos agora são calculados a partir dos resultados persistidos das partidas Sub-20, em vez de depender da tabela geral da carreira, que podia estar desatualizada.
- A classificação final é salva no estado da carreira e o histórico registra a colocação real.
