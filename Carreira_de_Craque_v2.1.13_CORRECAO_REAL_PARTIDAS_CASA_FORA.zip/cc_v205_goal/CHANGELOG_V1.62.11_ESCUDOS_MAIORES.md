# Carreira de Craque v1.62.11 — Escudos da LaLiga maiores

- Aumentado moderadamente o tamanho dos escudos do Real Betis, Celta Vigo e Levante.
- Tamanho padrão desses três escudos: 36×36 px (antes 29×29 px).
- Variante grande: 50×50 px (antes 43×43 px).
- Ajuste aplicado somente aos três clubes solicitados; os demais escudos e sistemas permanecem inalterados.
- Cache do service worker atualizado para forçar a nova versão dos arquivos.
