# Carreira de Craque v1.62.77 — Bundesliga jogável (integração inicial)

- Adicionada a Alemanha à seleção de país e clube na criação de carreira.
- Integrados os 18 clubes da Bundesliga 2026/27, incluindo Schalke 04, SC Paderborn e SV Elversberg.
- Criado calendário de turno e returno com 34 rodadas e 306 partidas.
- Adicionada a Bundesliga ao menu LIGAS e à visualização de classificação, calendário e estatísticas da liga.
- Integrado o elenco de 22 vagas por clube para permitir partidas, escalação e simulação nesta versão inicial.
- Adicionados links de escudos enviados pelo usuário como fontes remotas de exibição.

## Limitação importante desta integração
Os 22 registros de cada equipe são jogadores provisórios gerados para habilitar a jogabilidade. Eles **não** representam os 396 jogadores reais da lista enviada nem foram validados como elenco oficial. Alguns links de escudos também são fontes de terceiros e podem falhar ou não ser transparentes. A substituição por elencos reais auditados e escudos locais/offline deve ser tratada como uma etapa posterior antes de chamar o pacote de versão final licenciada.
