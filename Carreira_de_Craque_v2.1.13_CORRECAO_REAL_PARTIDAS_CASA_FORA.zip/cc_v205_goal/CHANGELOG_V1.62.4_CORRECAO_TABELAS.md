# Carreira de Craque v1.62.4 — Correção definitiva da classificação

- A classificação passa a usar exclusivamente o placar salvo no próprio confronto (`fixture.score`), sempre na orientação mandante–visitante.
- Removida a substituição do placar do calendário por dados do histórico individual do jogador. Versões antigas gravavam `homeGoals`/`awayGoals` na perspectiva do atleta em partidas fora de casa, o que podia inverter vitórias, empates e derrotas — especialmente na Série A.
- A reconstrução da tabela continua abrangendo a divisão ativa e as ligas paralelas, com 3 pontos por vitória, 1 por empate e 0 por derrota.
