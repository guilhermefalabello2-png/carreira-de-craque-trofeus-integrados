# Atualização — IDs exclusivos de troféus

- Criado `TROPHY_REGISTRY`, independente do `COMPETITION_LOGO_REGISTRY` e dos IDs de clubes.
- Cadastrados os nove IDs permanentes solicitados, ligados aos IDs internos existentes das competições.
- A sala `Jogador → Legado → Conquistas` agora consulta o registro de troféus, exibe a temporada e o nome da competição.
- Imagens ausentes exibem um espaço reservado discreto; não há imagens inventadas nem ícones quebrados.
- As conquistas e os dados salvos não são migrados, apagados ou regravados por esta atualização.
- Para adicionar uma imagem futuramente, basta colocar o PNG com o nome exato do ID em `assets/trophies/`.

Compatibilidade: projeto web/offline existente, Android e computadores.

- Normalização e validação de conquistas profissionais também reconhecem Ligue 1 e Bundesliga, para que seus títulos possam consultar os IDs próprios de troféu.
