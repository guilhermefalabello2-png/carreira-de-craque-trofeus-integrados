# Carreira de Craque v1.62.16 — Escudos PNG da LaLiga

- Barcelona: substituído o arquivo de imagem anterior por escudo PNG quadrado do catálogo ESPN.
- Real Madrid: substituído o arquivo JPG antigo por escudo PNG quadrado do catálogo ESPN.
- Espanyol: substituída a imagem horizontal que deixava o escudo visualmente pequeno por PNG quadrado e incluído no destaque de escudos da LaLiga na tela Ligas.
- Mantido o restante dos clubes, dados de carreira, tabelas e calendários.
- Cache do service worker atualizado para forçar a nova versão dos arquivos.
