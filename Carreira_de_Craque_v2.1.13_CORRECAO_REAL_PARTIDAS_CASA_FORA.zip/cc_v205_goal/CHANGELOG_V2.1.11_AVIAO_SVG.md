# Carreira de Craque v2.1.11 — Ícone de avião SVG

- Substituído o símbolo diagonal semelhante a avião de papel/Telegram pelo SVG minimalista de uma aeronave vista de cima.
- A aeronave possui fuselagem central, asas laterais e cauda traseira, em branco e com 18×18 px.
- Ícone de casa preservado.
- A função compartilhada `matchVenueIcon(isHome)` continua determinando o mando pelo confronto real, mantendo a aplicação no calendário da aba PARTIDAS em ligas e copas.
- Nenhuma alteração em calendário, confrontos, resultados, simulação ou escudos.
